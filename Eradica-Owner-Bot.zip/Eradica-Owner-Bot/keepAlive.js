const express = require("express");

function keepAlive() {
  const app = express();

  app.get("/", (req, res) => {
    res.send("Bot läuft!");
  });

  app.listen(3000, () => {
    console.log("✅ KeepAlive-Server läuft auf Port 3000");
  });
}

module.exports = keepAlive;